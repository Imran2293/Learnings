package headFirstJava;

public class AbstractDriver extends Object {

	public static void main(String[] args){
		
		ABS obj = new Concrete2();
		obj.concrete();
		obj.absmethod();
		obj.concrete2();
		
	}
}
abstract class ABS{
	
	void concrete(){
		System.out.println("Concrete Abstract class");
	}
	
	abstract int absmethod();
	abstract void absmethod2();
	
	void concrete2(){
		System.out.println("Concrete2 Abstract Class");
	}
}
class Concrete2 extends ABS{
	
	@Override
	int absmethod(){
		
		System.out.println("Subclass OR Method");
		
		return 2;
	}
	
	void concrete2(){
		System.out.println("SubClass Method");
	}

	@Override
	void absmethod2() {
		// TODO Auto-generated method stub
		
	} 
}
