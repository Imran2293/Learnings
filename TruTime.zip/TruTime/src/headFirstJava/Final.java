package headFirstJava;

import java.util.ArrayList;

public class Final {

	static final int  x = 10;
	
	int y = 12;
	
	public void method1(int x){
		System.out.println(x);
	}
	
	public static void main(String[] args){
		
		Final fc = new Final();
		
	System.out.println("Static Final x value: " + x);
	/*fc.method1(20);
	*/fc.method2(30);
	System.out.println(fc.y);
	fc.method3(24);
	
	Integer i =3;
	int y =i;
	
	ArrayList<Object> list = new ArrayList<>();
	list.add(3);
	list.add(4);
	list.add("String");
	
	System.out.println("Index 0 value of AL is: "+list.get(0));
	System.out.println("Index 0 value of AL is: "+list.get(2));
	
	
	
	}
	
	public void method2(final int x){
		System.out.println(x);
	}
	
	public void method3(final int y){
		System.out.println(y);
	}
}
