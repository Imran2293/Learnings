package headFirstJava;

import java.awt.Color;

abstract class AbstractClass {

	int i ;
	
	public AbstractClass(){
		i=20;
	}
	
}


 public class Concrete extends AbstractClass{
	
	public static void main(String[] args){
		
		AbstractClass c = new Concrete();
		System.out.println(c.i);
		Hippo hp = new Hippo("Hippopotamus");
		String NameofTheAnimal = hp.getName();
		System.out.println(NameofTheAnimal);
	}
}
 
class Animal{

	private String name;
	
	public Animal(String animalName){
		
		name = animalName;
		
	}
	
	public String getName(){
		
		return name;
	}
}

class Hippo extends Animal{
	
	Color color;
	


	public Hippo(String animalName) {
		super(animalName);
	}
	
	
	
}