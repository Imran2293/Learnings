package headFirstJava;

public class ExceptionHandling {
	
	public static void main(String args[]) {
		
		String test = "yes";
		
		try{
			System.out.println("start try");
			ExceptionHandling.doRisky(test);
			System.out.println("end try");
		}
		catch(Exception e){
			System.out.println("Exception");
		}
		finally{
			System.out.println("finally");
		}
		
		System.out.println("end of main");
	}
	
	static void doRisky(String test) throws Exception{
		
		System.out.println("start Risky");
		
		if("yes".equals(test)){
			throw new Exception();
		}
		
		System.out.println("End Risky");
		return;
	}

}
