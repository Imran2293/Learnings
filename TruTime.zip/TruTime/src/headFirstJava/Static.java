package headFirstJava;

public class Static {

	static int count ;
	
	public Static(){
		count++;
		System.out.println("No of Objects = "+ count);
	}
	
	public static void main(String[] args) {

	Static[] sc = new Static[5];
	Static.nonStaticMethod();
	
	for (int x=0; x<5 ; x++){
		
		sc[x] = new Static();
	}
	
	
	
		
	}
	
	public static void nonStaticMethod(){
		
		count = 25;
	}

}
