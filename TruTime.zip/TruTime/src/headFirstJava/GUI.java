package headFirstJava;

import java.awt.*;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import headFirstJava_swing.MyDrawPanel;

public class GUI extends JPanel implements ActionListener {

	JButton button;
	
	JFrame frame;

	public static void main(String[] args) {

		GUI gui = new GUI();
		gui.go();

	}

	public void go() {

		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		button = new JButton("click me");
		button.addActionListener(this);

		MyDrawPanel drawPanel = new MyDrawPanel();

		frame.getContentPane().add(BorderLayout.SOUTH, button);
		frame.getContentPane().add(BorderLayout.CENTER, drawPanel);
		frame.setSize(300, 300);
		frame.setVisible(true);

	}

	@Override
	public void actionPerformed(ActionEvent e) {

		button.setText("I've been Clicked");
		frame.repaint();
	}

}
