package headFirstJava;

import javax.sound.midi.*;

public class Chapter11 {
	
	public void play() throws MidiUnavailableException {
		
		Sequencer seq = MidiSystem.getSequencer();
	}

}
