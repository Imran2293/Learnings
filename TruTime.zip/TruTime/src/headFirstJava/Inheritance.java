package headFirstJava;

public class Inheritance {

	public static void main(String[] args) {
		
		/*Inheritance i = new Inheritance();
		i.CreateApprover();
		i.Display();*/
		
		
		
		Inheritance s =  new Inherited();
		s.CreateApprover(5);
		s.Display(6);
		
		Inherited i = (Inherited) s;
		i.CreateApprover(12);
		i.Display(5);
		i.SubMethod1();
		i.SubMethod2();
		
	
	
		/*Inherited ss = new Inherited();
		ss.CreateApprover(55);
		ss.Display(44);
		ss.SubMethod1();
		ss.SubMethod2();*/

	}
	
	void Display(int i){
		System.out.println("Display - Super Class");
	}
	
	void CreateApprover(int y){
		System.out.println("Create Approver - Super Class");
	}

}


class Inherited extends Inheritance{
	
	void SubMethod1(){
		System.out.println("SubMethod1 - Sub Class");
	}
	
	void SubMethod2(){
		System.out.println("SubMethod2 - Sub Class");

	}
	
	void Display(int i){
		System.out.println("Display - Sub Class");
	}
	
	void CreateApprover(int y){
		System.out.println("Create Approver - Sub Class");
	}
	
}
