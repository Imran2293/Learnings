package headFirstJava;

public class Chapter10 {
	
	int ssize = 20;
	public static void main(String args[]){
	
		/*Subclass sc = new Subclass(5);
		sc.method1();
		sc.setSize(21);*/
		
//		System.out.println(ssize);
		
		Chapter10 ch = new Chapter10();
		String[] s = {};
		ch.main(s);
		
		
		
		
	}
	
	
	public void setSize(int y){
		
		ssize = y;
			
	}
	
	public int getSize(){
		
		return ssize;
	}
	
}

class Subclass{
	
	int size;
	Subclass sc = new Subclass();
	private Subclass(){
		
	}
	
/*	public Subclass(int x){
		
		size=x;
		
		System.out.println(size);
	}
	*/
	public void method1(){
		Math.random();
		
	}
	
	public void setSize(int y){
		
		size = y;
			
	}
	
	public int getSize(){
		
		return size;
	}
	
}
