package headFirstJava;

public class TrueOrFalse {
	
	int i;
	
	public TrueOrFalse(){
		
	}

	
	public static void method(){
		
		this.i;
		
	}
}
