package headFirstJava;

public class AnimalsHub {
	
	public static void main(String args[]){
		
		AnimalsHub[] a = new AnimalsHub[3];
		a[0] = new Bow();
		a[1] = new Meow();
		a[2] = new BigShow();
		
		a[0].eat();
		a[1].eat();
		a[2].eat();
	}
	
	void eat(){
		
	}

}

class Bow extends AnimalsHub{
	
	void eat(){
		System.out.println("Dogs eat Pedigree");
	}
}

class Meow  extends AnimalsHub{
	
	void eat(){
		System.out.println("Cats eat Rats");
	}
}

class BigShow extends AnimalsHub{
	void eat(){
		System.out.println("Hippos eat Grass");
	}
}