package headFirstJava;

import java.sql.Time;
import java.util.Calendar;
import java.util.Date;

public class TestBox {

	int i;
	Integer j;
	String str = "2";
	Double d = 432.10;
	
	public static void main(String[] args) {
	
		TestBox tx = new TestBox();
		tx.go();

	}
	
	public void go(){
		
		j=i;
		
		int k = Integer.parseInt(str);
		
		double dd = Double.parseDouble("423.10");
		
		boolean b = new Boolean("true").booleanValue();
		
		double doubl = 222.22;
		
		String str = ""+doubl;
		
		String s = String.format("%,6.1f", 25.000);
		
		String twoargs = String.format("First Number is %,.3f and the second one is %<,.4f", 12121212.12345);
		
		System.out.println(twoargs);
		
		System.out.println(s);
		
		Date today = new Date();
		
		String DateToday = String.format("%tc",today );
		
		String TimeOnly = String.format("%tr",today );
		
		String DayOftheWeek = String.format("%tA, %<tB %<td",today );
		
		System.out.println(DateToday);
		
		System.out.println(TimeOnly);
		
		System.out.println(DayOftheWeek);
		
		Calendar cd = Calendar.getInstance();	
//		cd.set(year, month, date, hourOfDay, minute, second);
		
		/*System.out.println(str);
		
		System.out.println(b);
		
		System.out.println(dd);
		
		System.out.println(j);
	
		System.out.println(i);*/
		
		System.out.println(k);
		
	}

}
