package headFirstJava;

import java.awt.Color;

public class Mini {

	Color color;
	
	public Mini(){
		
	}
	
	
	public Mini(int size){
		
	}
}
