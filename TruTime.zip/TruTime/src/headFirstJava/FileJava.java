package headFirstJava;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileJava {
	
	public static void main(String args[]) throws IOException{
	
		File file = new File("C:\\Users\\rj815\\Cummins\\Bundle 4\\APCM_GPCM\\APCM_GPCM_Smoke_Test Logs_Tenant_level.xlx");
		String absolutePath = file.getAbsolutePath();
		boolean isDelete = file.delete();

//		System.out.println(absolutePath);
//		System.out.println(isDelete);
//		
		File file1 = new File("C:\\Users\\rj815\\Cummins\\Bundle 4\\APCM_GPCM\\Sample.txt");
		BufferedWriter writer = new BufferedWriter(new FileWriter(file1));
		writer.write("Imran");
		writer.write(" Hussain");
		writer.newLine();
		writer.write("CTS");
		writer.newLine();
		writer.write("Chennai");
		writer.flush();
		
		FileReader freader = new FileReader(file1);
		BufferedReader reader = new BufferedReader(freader);
		
		String read = null;
		
		while((read = reader.readLine()) != null){
			
			System.out.println(read);
			
		}
		
		reader.close();
	}
	


}
