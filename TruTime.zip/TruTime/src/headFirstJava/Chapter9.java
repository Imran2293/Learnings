package headFirstJava;

public class Chapter9 extends Object{
	
	 int num = 9;

	public static void main(String[] args){
		
		Chapter9 ch = new Chapter9();
		ch.Chapter9();
		System.out.println(ch.getClass());
		System.out.println(ch.toString());
	}
	
	public Chapter9(){
		
		num = 10;
		System.out.println(num);

	}
	
	public void Chapter9(){
		
		System.out.println("Method Name same as Class Name");
	}

}
