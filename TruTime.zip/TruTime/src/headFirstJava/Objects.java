package headFirstJava;

public class Objects {

	public static void main(String[] arg) {
		/*Dog d1 = new Dog();
		d1.Display();
		d1.go();*/
		
		Dog d2 = new Dog2();
		d2.Display();
		d2.go();
		System.out.println(d2.getClass());
		
		
	}

}

class Dog extends Object implements Pet,Runnable {

	public Object getObject(Object o) {

		return o;
	}

	public void go() {
		System.out.println("Dog's go Method");
	}

	@Override
	public void Display() {
		System.out.println("Implemented Method of Pet Interface");
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}

class Dog2 extends Dog {

	public void Display() {
		System.out.println("ORidden Dog2's Method");
	}
}

interface Pet {

	abstract void Display();

}