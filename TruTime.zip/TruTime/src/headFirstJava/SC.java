package headFirstJava;

public class SC {
	
	SC s = new SC();
	
	public SC (int i){
		
	}
	
	public SC(String s){
		
	}
	
	public SC(String s, int i){
		
	}

	public SC() {
		// TODO Auto-generated constructor stub
	}

}

class SonOfBoo extends SC{

	public SonOfBoo(int i) {
		super("Fred");
	}
	
	public SonOfBoo(String str){
		super(42);
	}
	
}
