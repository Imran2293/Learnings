package headFirstJava_MultiThreading;




class MyRunnable implements Runnable{

	@Override
	public void run() {
		go();
	}
	
	void go(){
//		System.out.println("top' of' stack'");
		gomore();
	}
	
	void gomore(){
		System.out.println("second' in' stack'");
	}
}

public class TesterThread {

	public static void main(String[] args) {
		
//		System.out.println("Starts with Main");
		MyRunnable job = new MyRunnable() ;
		Thread myThread = new Thread(job);
		myThread.start();
		System.out.println("Back to Main");

	}

}
