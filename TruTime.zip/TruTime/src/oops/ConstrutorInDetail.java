package oops;

public class ConstrutorInDetail {
	
	public static void main(String args[]){
		Child ch = new Child(6033,"Imran",40000);
	}

}

class Parent{
	int id;
	String name;
	
	Parent(int identity, String user){
		id=identity;
		name=user;
	}
	
}

class Child extends Parent {

	int amount;
	Child(int identity, String user,int Salary) {
		super(identity, user);
		amount=Salary;
		System.out.println(id+" "+name+" "+amount);
	}
	
}