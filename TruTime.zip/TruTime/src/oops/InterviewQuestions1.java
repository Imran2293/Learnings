package oops;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class InterviewQuestions1 {

	static  int count=0;

	public static void main(String[] args) throws Exception {
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\rj815\\Selenium\\Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.navigate().to("http://leafground.com/");
		driver.manage().window().maximize();
		WebDriverWait wait = new WebDriverWait(driver,20);
		
		WebElement Link = driver.findElementByXPath("//h5[text()='HyperLink']");
		wait.until(ExpectedConditions.elementToBeClickable(Link));
		boolean enabled = Link.isEnabled();
		if(enabled==true){
//			Link.click();
			Actions builder = new Actions(driver);
			builder.click(Link);
		}
		
		//HyperLink page
		
		List<WebElement> Links = driver.findElementsByTagName("a");
		try{
			for(WebElement each: Links){
				if(each.isEnabled()){
					count++;
				}
		}
			System.out.println(count);
		}
		
		catch(Exception e)
		{
			throw new Exception("Links are Disabled");
		}
		
			
		}
		

	}


