package oops;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class String1 {

	public static void main(java.lang.String[] args) throws IOException {
		
//		String str1 = new String("abc");
//		String str2 = new String("abc");
//		
//
//		String str3 = new String("abc");
//		String str4 = "abc";
//		String intern = str4.intern();
		String st;
		
//		System.out.println("str1:"+ str1.hashCode());
//		System.out.println("str1:"+ str2.hashCode());
//		System.out.println("str1:"+ str3.hashCode());
//		System.out.println("str1:"+ intern.hashCode());
		
		//Read File using Buffered Writer --> allows reader to read data from the buffer 
//		instead of directly reading from stream; helps reading line by line
		File fi = new File("C:\\Users\\rj815\\Desktop\\Selenium\\Sample.txt");
		BufferedReader bf = new BufferedReader(new FileReader(fi));
		FileReader fr = new FileReader(fi);
		
//		StringBuilder sb = new StringBuilder();
		while((st = bf.readLine()) != null){
			
			System.out.println(st);
		}
		bf.close();
		
		String file = "C:\\Users\\rj815\\Desktop\\Selenium\\NewDoc1.txt";
		FileWriter fw;
		
		BufferedWriter bw = new BufferedWriter(new FileWriter(file));
		bw.write("Imran");
		bw.write("\r\n");
		bw.write("Hussain");
		bw.close();
		
		
		
	}

}
