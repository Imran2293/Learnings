package oops;

public abstract class Abstraction {

	abstract void method1();
	
	public static void main(String args[]){
		
		subClass sc = new subClass();
		sc.method1();
		sc.method2();
	}

}

class subClass extends Abstraction{

//	@Override
	void method3() {
		
		System.out.println(" Method");
		
	}
	
	void method2(){
		System.out.println("Normal Method");
	}

	
	void method1() {
		// TODO Auto-generated method stub
		System.out.println("Overridden Method");

	}
}
