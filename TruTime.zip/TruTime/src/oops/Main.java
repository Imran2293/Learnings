package oops;

public class Main{
	
public static void main(String[] args) {
		
		Child ch = new Child(10);
//		Constructors cons = new Constructors("Imran");

	}
}

 class Parent {

	static String myName=null;
	
	public Parent(){
		System.out.println("No Argument Constructor");
		
	}
	
	public Parent(String name){
		this();
		myName = name;
		System.out.println("Parameterized Constructors:"+myName);
		
	}
	
}

class Child extends Parent{
	
	int number;
	public Child(String name){
		super(name);
		System.out.println("Child Non Parameterized Constructor");
	}
	
	public Child(int num){
		
		this("Hussain");
		number = num;
		System.out.println("Child Parameterized Constructor"+number);
	}
	
	
}	


