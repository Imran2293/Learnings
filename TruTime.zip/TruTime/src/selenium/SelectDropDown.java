package selenium;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SelectDropDown {

	public static void main(String[] args) throws IOException {
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\rj815\\Selenium\\Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
//		driver.get("");
		driver.navigate().to("http://leafground.com/");
		driver.manage().window().maximize();
		
		
		Properties ps = null;
		ps = new Properties();
		FileInputStream objfile = new FileInputStream(System.getProperty("C:\\Users\\rj815\\workspace\\TruTime\\src\\Application.properties"));
		ps.load(objfile);
		ps.getProperty("LeafGroundWebTable");
		driver.findElement(By.xpath("LeafGroundWebTable")).click();
		
//		driver.findElementByXPath("(//a[@class='wp-categories-link maxheight'])[5]").click();
//		WebElement SelectTag = driver.findElementById("dropdown1");
//		
//		Select dropdown = new Select(SelectTag);
//		List<WebElement> options = dropdown.getOptions();
//		for(WebElement each:options){
//			System.out.println(each.getText());
//			
//		}
//		
//		List<String> list1 = new ArrayList();
//		for(WebElement each1 : options){
//			list1.add(each1.getText());
//		}
//		list1.remove("Select training program using Index");
//
//		System.out.println("Unsorted List"+list1);
//		
//		List<String> tempList = new ArrayList(list1);
//		Collections.sort(tempList);
//		
//		
//		System.out.println("Sorted Dropdown"+ tempList);
//		
//		if(tempList.equals(list1)){
//			System.out.println("Sorted");
//		}
//		else{
//			System.out.println("Not Sorted");
//		}
//		driver.close();

	}

}
