package selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class IndexOfFrame {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\rj815\\Selenium\\Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.navigate().to("http://demo.guru99.com/test/guru99home/");
		driver.manage().window().maximize();
		
		int size = driver.findElementsByTagName("iframe").size();
		
		for(int i=0; i<=size; i++){
			driver.switchTo().frame(i);
			int size2 = driver.findElementsByXPath("html/body/a/img").size();
			System.out.println(size2);
			driver.switchTo().defaultContent();
		}
		
		driver.navigate().refresh();
		WebDriverWait wait = new WebDriverWait(driver,20);
		wait.until(ExpectedConditions.refreshed(ExpectedConditions.stalenessOf(element)));
	}

}
