package selenium;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WindowHandle {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\rj815\\Selenium\\Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.navigate().to("http://leafground.com/");
		driver.manage().window().maximize();
		
		driver.findElementByXPath("//*[contains(text(),'Window')]").click();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		WebElement dummy = driver.findElementByXPath("//*[contains(text(),'Window')]");
		String CurrentWindow = driver.getWindowHandle();
		
		
		driver.findElementByXPath("//*[contains(text(),'Open Multiple Windows')]").click();
		List<String> allWindows = new ArrayList<String>(driver.getWindowHandles());
		int size = allWindows.size();
		System.out.println(size);
		
//		Iterator<String> ite = allWindows.iterator();
//		if(ite.hasNext()){
//			driver.switchTo().window(ite.next());
//			driver.manage().window().maximize();
//			String title = driver.getTitle();
//			System.out.println(title);
//		}
		
		for(String each: allWindows){
			if(!each.equals(CurrentWindow)){
				driver.switchTo().window(each);
				String title = driver.getTitle();
				System.out.println(title);
			}
		}
		
		driver.close();
//		driver.manage().window().maximize();
//		String title = driver.getTitle();
//		System.out.println(title);
		
//		for(int i=0;i<size;i++){
//			if(i==1){
//			driver.switchTo().window(allWindows.get(1));
//		}
		
		WebDriverWait wait = new WebDriverWait(driver,20);
		WebElement until = wait.until(ExpectedConditions.visibilityOf(dummy));
		wait.until(ExpectedConditions.alertIsPresent());
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.MINUTES);
		
		FluentWait<WebDriver> wait1 = new FluentWait<WebDriver>(driver);
		wait1.pollingEvery(Duration.ofSeconds(60))
		.pollingEvery(Duration.ofSeconds(2)).ignoring(NoSuchElementException.class);

//		driver.getScreenshotAs(arg0)
		
//		ExtentReports rep = new ExtentReports();
//		Screenshot sc = new AShot();

	}



}
