package selenium;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnection {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		//Load JDBC driver
		Class.forName("");
		//Create Connection to DB
		Connection con = DriverManager.getConnection("", "", "");
		Statement statement = con.createStatement();
		//Execute the query and store the result in ResultSet
		ResultSet resultSet = statement.executeQuery("Select * from MMM_ORDER_STATE with (nolock) where WHMS_ORD_STUS_CODE ='ASGN'");
		//Get the string value from resultset
		String s1 = resultSet.getString(1);
		

	}

}
