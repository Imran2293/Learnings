package selenium;

public class WriteExcel {

	public static void main(String[] args) {
		
		FileInputStream fis = new FileInputStream("D:\\Test.xlsx");
		XSSFWorkbook book = new XSSFWorkbook(fis);
		
		
	}

}
