package selenium;

import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PageStatus {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\rj815\\Selenium\\Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.navigate().to("https://cummins365.sharepoint.com/sites/dev_QSI35_dev/lists/Change%20Request/allitems.aspx");
		driver.findElementById("userNameInput").sendKeys("rj815@cummins.com");
		driver.findElementById("passwordInput").sendKeys("Livelong@01");
		driver.findElementById("submitButton").click();
		
		WebDriverWait wait = new WebDriverWait(driver,10);
		Alert setAlert = wait.until(ExpectedConditions.alertIsPresent());
		
		
		
		
		// Check states of the page
		JavascriptExecutor js = (JavascriptExecutor)driver;
		String states = js.executeScript("return document.readyState").toString();
		
		switch(states){
		
		case "loading": System.out.println("Still loading");
		break;
		
		case "interactive": System.out.println("The document has finished loading.But sub-resources such as images, stylesheets and frames are still loading.");			
		break;
		
		case "complete": System.out.println("Page is fully loaded");
		break;
		
		default:
		break;
		}

	}

}
