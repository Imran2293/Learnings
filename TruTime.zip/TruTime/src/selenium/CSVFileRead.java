package selenium;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;

public class CSVFileRead {

	public static void main(String[] args) throws FileNotFoundException {
		
//		File file = new File("");
		String[] str=null;
		CSVReader reader = new CSVReader(new FileReader("C:\\Users\\rj815\\Desktop\\Selenium\\Sample Docs\\SampleCSV.csv"));
		try {
			while((str=reader.readNext())!=null){
				if(str!=null){
					System.out.println(Arrays.toString(str));
				}
			}
		} catch (CsvValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
