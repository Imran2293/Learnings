package selenium;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class CheckBox {

	public static void main(String[] args) throws SQLException, ClassNotFoundException, InterruptedException {
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\rj815\\Selenium\\Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.navigate().to("http://leafground.com/");
		driver.manage().window().maximize();
//		Connection con =DriverManager.getConnection("", "", "");
//		Class.forName("");
//		Statement stmt = con.createStatement();
//		ResultSet rs = stmt.executeQuery("");
//		rs.getString(2);
		Actions builder = new Actions(driver);
		builder.sendKeys(Keys.PAGE_DOWN).perform();
		Thread.sleep(5000);
		
		
//		int size = driver.findElementsByTagName("iframe").size();
//		
//		driver.switchTo().f
		
//		WebElement checkBoxPage = driver.findElementByXPath("//img[@alt='Checkbox']");
//		
//		WebElement CheckBox = driver.findElementByXPath("(//input[@type='checkbox'])[1]");
//		if(!CheckBox.isSelected()){
//			CheckBox.click();
//		}
//		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		String title = (String)js.executeScript("return document.title");
		
		js.executeScript("window.scrollBy(0,1000)");
		js.executeScript("arguments[0].scrollIntoView();",Element);
		js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
		
		

	}

}
