package selenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebTable {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\rj815\\Selenium\\Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.navigate().to("http://leafground.com/");
		driver.manage().window().maximize();
		
		driver.findElementByLinkText("Advance Web Table").click();
		WebElement Table = driver.findElementById("table_id");
		String text = Table.findElement(By.xpath("(//td[@class='sorting_1'])[1]")).getText();
		System.out.println(text);
		
//		driver.findElementByXPath("//img[@alt='Table']").click();
//		
//		List<WebElement> TotalRows = driver.findElementsByXPath("//table[@id='table_id']/tbody/tr");
//		System.out.println(TotalRows.size());
//		
//		List<WebElement> TotalCols = driver.findElementsByTagName("td");
//		System.out.println(TotalCols.size());
		
//		driver.fin

	}

}
