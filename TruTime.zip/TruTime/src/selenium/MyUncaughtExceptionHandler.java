package selenium;

public class MyUncaughtExceptionHandler  implements Thread.UncaughtExceptionHandler {

		
		public void uncaughtException(Thread t,Throwable e){
			
		}

	}

