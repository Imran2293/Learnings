package selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

public class SecurityHandling {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\rj815\\Selenium\\Driver\\chromedriver.exe");
		DesiredCapabilities set = DesiredCapabilities.chrome();
		set.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		ChromeDriver driver = new ChromeDriver(set);
		driver.manage().window().maximize();
		driver.navigate().to("https://cummins365.sharepoint.com/sites/dev_QSI35_dev/lists/Change%20Request/allitems.aspx");

	}

}
