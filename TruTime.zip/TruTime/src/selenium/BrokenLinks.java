package selenium;

import java.net.HttpURLConnection;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class BrokenLinks {

	public static void main(String[] args) {
		
//		HttpURLConnection http = new HttpURLConnection();
		List<String> aList = Arrays.asList("Geeks", "for", 
                "GeeksQuiz", "GeeksforGeeks", "GFG"); 

//    Set<String> hSet = new HashSet<String>(aList); 
//    hSet.addAll(aList); 
//
//    for(String each: hSet){
//    	System.out.println(each);
//    }
    
    
    
    List<String> lL = new LinkedList<>(); 
    for (String t : aList) { 
    	  
        // Add each element into the lL 
        lL.add(t); 
    }
    
    System.out.println(lL);
    
	}

}
