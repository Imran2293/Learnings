package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;

public class LaunchBrowsers {

	public static void main(String[] args) {
	
		/*System.setProperty("webdriver.ie.driver", "C:\\Users\\rj815\\Selenium\\Driver\\IEDriverServer.exe");
		WebDriver driver =  new InternetExplorerDriver();
		driver.get("https://www.redbus.com");
		WebElement go = driver.findElement(By.id("go"));
		Actions builder = new Actions(driver);
		builder.click(go).build().perform();*/
		
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\rj815\\Selenium\\Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.navigate().to("https://www.redbus.com");
		WebElement go = driver.findElement(By.id("go"));
		Actions builder = new Actions(driver);
		builder.click(go).build().perform();
		
	}

}
