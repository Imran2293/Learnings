package selenium;

public interface InterfaceExample {
	
	int var1=10;

}
