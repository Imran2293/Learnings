package workBook;

public class MethodOverRiding1 {

	public static void main(String[] args) {
		
		String str="core/pages/viewemployee.jsff";
		String first = str.replaceFirst(".*/(\\w+).*", "$1");
		System.out.println(first);
		
		
		
	    

	}

}
