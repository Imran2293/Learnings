package workBook;

public class Prime {

	public static void main(String[] args) {
		
		int n=19;
		boolean bNon = false;
		
		for(int i=2; i<=n/2; i++){
			
			if(n%i==0){
				System.out.println("Non Prime");
				bNon=true;
				break;
			}
		}
		
		if(!bNon){
			System.out.println("Prime");
		}

	}

}
