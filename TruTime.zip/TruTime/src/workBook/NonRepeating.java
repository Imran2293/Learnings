package workBook;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class NonRepeating {

	public static void main(String[] args) {
		
		int[] arr1 = {2,3,1,2,3,5,4};
		int n=arr1.length;
		
		Map<Integer,Integer> mp = new HashMap();
		
		for(int i=0; i<n; i++){
			
			if(mp.containsKey(arr1[i])){
				mp.put(arr1[i], mp.get(arr1[i])+1);
			}
			else{
				mp.put(arr1[i], 1);
			}
		}
		
		for(Map.Entry<Integer, Integer> x: mp.entrySet()){
			
			if(x.getValue()==1){
				System.out.println("Non Repeating Numbers are: "+ x.getKey()+" ");
			}
//			else if(x.getValue()!=1){
//				System.out.print(x.getKey()+" ");
//			}
		}
		
		Set li = new HashSet();
		for(int i=0; i<arr1.length; i++){
			for(int j=i+1; j<arr1.length;j++){
				if(arr1[i]==arr1[j]){
					li.add(arr1[j]);
				}
			}
			
	}
		li.toArray();
		
		System.out.println("Duplicate Numbers are:"+li);

}
}
