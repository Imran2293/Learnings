package workBook;

import java.util.Arrays;

public class UpperCase {

	public static void main(String[] args) {
		
		String name = "all first Word needs to be Capitalized";
		String[] split = name.split("\\s");
		System.out.println(Arrays.toString(split));
		String Capital ="";
		
		for(String each: split){
			String first = each.substring(0,1);
			String next = each.substring(1);
			Capital+=first.toUpperCase()+next+" ";
		}
		
		
		System.out.println(Capital);
	}
	

}
