package workBook;

public class SumofDigits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num = 279;
		int sum = 0,remainder;
		while(num>0){
			remainder = num%10;
			sum = sum+remainder;
			num=num/10;
		}

		System.out.println(sum);
		
		//2
		
		String value = String.valueOf(num);
		char[] charArray = value.toCharArray();
		for(char c : charArray){
			sum = sum+Integer.parseInt(""+c);
		}
		
		System.out.println(sum);
	}

	
	
	
}
