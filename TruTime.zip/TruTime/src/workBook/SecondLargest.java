package workBook;

public class SecondLargest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] num = {34,34,34};
		int first,second;
		
		first=second=Integer.MIN_VALUE;
	
		for (int i = 0; i < num.length; i++) {
			if(num[i]>first){
				second = first;
				first = num[i];
			}
			else if (num[i]>second && num[i] != first){
				second = num[i];
			}
		}
		
		if(second == Integer.MIN_VALUE){
			System.out.println("No");
		}
		else{
			System.out.println(second);
		}
		
	}
	

}
