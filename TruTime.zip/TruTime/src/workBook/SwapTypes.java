package workBook;

public class SwapTypes {

	public static void main(String[] args) {
		
		int x=10,y=15;
		
//		x=x^y; // 1010 ; 1111 = 0101
//		y=x^y; // 0101 ; 1111 = 1010
//		x=x^y; // 0101 ; 1010 = 1111
//		
		x = x*y;
		y = x/y;
		x = x/y;
		
		System.out.println(x+" "+y);

	}

}
