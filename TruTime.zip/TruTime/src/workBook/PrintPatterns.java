package workBook;

public class PrintPatterns {

	public static void main(String[] args) {
		
		//Floyd's Half Pyramid using numbers
		
		int n=10;
//		
//		for(int i=1; i<=n; i++){
//			for(int j=1; j<=i; j++){
//				System.out.print(j+" ");
//			}
//			System.out.println();
//		}
		
		//Using *
		
		int nu=5;
		for(int i=1; i<=nu; i++){
			for(int j=1; j<=i; j++){
				System.out.print("* ");
			}
			System.out.println();
			}
		
//		//Inverted
//		for(int i=n; i>=1; i--){
//			for(int j=1; j<=i; j++){
//				System.out.print(j+" ");
//			}
//			System.out.println();
//		}
		

	}

}
