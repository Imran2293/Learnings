package workBook;

public class PalindromeOrNot {

	public static void main(String[] args) {
		
		String str = "Malayalam",rev="";
		
//		int i=0,j=str.length()-1;
//		
//		boolean state;
//		
//		while(i<j){
//			if(str.charAt(i) != str.charAt(j)){
//				state=false;
//				
//				i++;
//				j--;
//			}
//		}
//		
//		state = true;
		for(int i= str.length()-1;i>=0;i--){
			rev=rev+str.charAt(i);
		}
		
		if(rev.equals(str)){
			System.out.println("Palindrome");
		}
		else{
			System.out.println("Not Palindrome");
		}
		
		
		int n = 221;
		
		int reve=0,rem;
		
		while(n!=0){
			rem=n%10;
			reve = reve*10+rem;
			n=n/10;
		}
		
		if(reve==n){
		
		System.out.println(reve);
		}
		else
		{
			System.out.println("No");
		}

	}

}
