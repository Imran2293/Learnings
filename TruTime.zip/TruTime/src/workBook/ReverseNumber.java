package workBook;

public class ReverseNumber {

	public static void main(String[] args) {
		
		int n=1145;
		int r,sum=0,temp;
		temp=n;
		
		while(n>0){
			r=n%10;
			sum=(sum*10)+r;
			n=n/10;
		}
		
		if(temp==sum){
			System.out.println("Palindrome");
		}
		else{
			System.out.println("Not a Palindrome");
		}
		System.out.println(sum);

	}

}
