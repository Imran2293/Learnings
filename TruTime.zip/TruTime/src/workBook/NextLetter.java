package workBook;

public class NextLetter {

	public static void main(String[] args) {
		
		//To Print Next letter of each character in a string
		String name = "IMRAN HUSSAIN";
//		char ch = 'a';
//		ch += 5;
//		System.out.println(ch);

		char[] array = name.toCharArray();
		for(int i=0; i<array.length; i++){
			array[i]+=1;
			System.out.print(array[i]);
				
				}
		String s="123456789";
		int int1 = Integer.parseInt(s);
		System.out.println(int1);
	}
	
	
	
	

}
