package workBook;

public class UpperCaseEachword {

	public static void main(String[] args) {
		
		/* Tried but didn't work*/
//		String str = "geeks for geeks";
//		String[] split = str.split("//s");
//		str="";
//		
//		for(int i=0; i<split.length; i++){
//			char upperCase = Character.toUpperCase(split[i].charAt(0));
//			str+=" "+upperCase+split[i].substring(1);
//		}
//		str= str.trim();
//		System.out.println(str);
//		
		String toBeCapped = "all first Word needs to be Capitalized";

		String[] tokens = toBeCapped.split("\\s");
		toBeCapped = "";

		for(int i = 0; i < tokens.length; i++){
		    char capLetter = Character.toUpperCase(tokens[i].charAt(0));
		    toBeCapped +=  " " + capLetter + tokens[i].substring(1);
		}
		toBeCapped = toBeCapped.trim();
		System.out.println(toBeCapped);
		
		String str = "Geekssss"; 
        String[] arrOfStr = str.split("s"); 
  
        for (String a : arrOfStr) {
            System.out.println(a); 
    } 


	}


}
