package workBook;

import org.jsoup.Jsoup;

public class RemoveTags {

	public static void main(String[] args) {
		
		String str = "<b><p> String with Tags </p></b>";
		System.out.println("String with tags"+" "+ str);
//		str=str.replaceAll("\\<.*?\\>", "");
//		System.out.println("String without tags"+str);
		System.out.println(Jsoup.parse(str).text());

	}

}
