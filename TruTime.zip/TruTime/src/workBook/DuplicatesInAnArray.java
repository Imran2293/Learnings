package workBook;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class DuplicatesInAnArray {

	public static void main(String[] args) {
		
//		int n=9;
		
//		 int[] original = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
//		    System.out.println("original array: " + Arrays.toString(original));
//		    
//		    // let's create an exact copy of the array
//		    int[] copy = Arrays.copyOf(original, 10);
//		    System.out.println("exact copy: " + Arrays.toString(copy));
//		    
		    
//		    int[] arr = new int[2]; 
//	        arr[0] = 10; 
//	        arr[1] = 20; 
//	  
//	        for (int i = 0; i <arr.length; i++) {
//	            System.out.println(arr[i]); 
//	    } 
		
		int a[] = {5,2,6,2,2,1,3,6,1,0};
		System.out.println(Arrays.toString(a));
//		Arrays.sort(a);
		Set li = new HashSet();
		Set li1 = new HashSet();
		
		
		for(int i=0; i<a.length; i++){
			for(int j=i+1; j<a.length;j++){
				if(a[i]==a[j]){
					li.add(a[j]);
//					System.out.println(a[j]);
				}
//				else if (a[i]!=a[j]){
//					li1.add(a[j]);
//				}
			}
			
		}
		
		System.out.println(li);
		System.out.println(li1);

	}

}
