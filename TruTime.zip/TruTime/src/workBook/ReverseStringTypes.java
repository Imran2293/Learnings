package workBook;

public class ReverseStringTypes {

	public static void main(String[] args) {
		
		String name = "Good Morning Everyone";
		//1
		StringBuffer Greeting = new StringBuffer("Good Morning Everyone");
		Greeting.reverse();
		System.out.println(Greeting);
		
		//2
		char[] cs = name.toCharArray();
		for (int i = cs.length-1; i >=0; i--) {
			
			System.out.print(cs[i]);
			
		}
		System.out.println();
	
		//3
		StringBuilder data = new StringBuilder(name);
		data.reverse();
		System.out.println(data);
		
		//4
		for(int i=name.length()-1; i>=0; i--)
		{
			System.out.print(name.charAt(i));
		}
	}

}
