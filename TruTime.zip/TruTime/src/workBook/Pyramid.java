package workBook;

public class Pyramid {

	public static void main(String[] args) {
		
		int rows=5,count=0,count1=0,k=0;
		for(int i = rows; i >= 1; i--) {
            for(int space = rows-i; space >=1; space--) {
                System.out.print("  ");
                count++;
            }
            while(k != 2 * i - 1) {
                if (count <= rows - 1) {
                    System.out.print((i + k) + " ");
                    count++;
                }
                else {
                    ++count1;
                    System.out.print((i + k - 2 * count1) + " ");
                }
                k++;
            }
            count1 = count = k = 0;
            System.out.println();

	}

}
}
