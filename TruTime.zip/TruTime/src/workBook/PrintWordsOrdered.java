package workBook;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class PrintWordsOrdered {

	public static void main(String[] args) {
		
		String[] arr1={"Zebra","Xerox","Imran","Abraham"};
		String[] arr2={"XIAZ"};
		
		
		Set<String> set1 = new LinkedHashSet<>();
		for(int i=0; i<arr1.length;i++){
			set1.add(arr1[i]);
		}
		
		System.out.println(set1);
		
		Set<String> set2 = new LinkedHashSet<>();
		for(int i=0; i<arr2.length;i++){
			set2.add(arr2[i]);
		}
		
		
		System.out.println(set2);
		
//		
//		Arrays.sort(arr);
//		for(String each: arr){
//		System.out.println(each);
//		}
		
//		HashMap<String,Integer> map = new HashMap<>();
//		for(int i=0; i<arr.length; i++){
//			map.put(arr[i],(i+1));
//		}
//		
//		HashMap<String,Inter>
//		
//		Arrays.sort(arr);
//		
//		for(int i=0; i<arr.length;i++){
//			System.out.print(map.get(arr[i])+" ");
//		}

	}

}
