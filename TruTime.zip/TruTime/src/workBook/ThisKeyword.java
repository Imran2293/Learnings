package workBook;

public class ThisKeyword {

	int InstaVar = 40;
	
	public static void main(String[] args) {
		
		ThisKeyword tk = new ThisKeyword();
		tk.methodn();

	}
	
	void method1(){
		int InstaVar=20;
		System.out.println("Instance Variable is: "+this.InstaVar);
		System.out.println("Local Variable value is: " +InstaVar);
	}
	
	void methodn(){
		System.out.println("Output of Method n");
		method1();
	}

}
