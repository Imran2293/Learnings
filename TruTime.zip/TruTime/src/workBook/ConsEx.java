package workBook;

public class ConsEx {

	public static void main(String[] args) {
		
		ConsEx ce1 = new ConsEx();
	
	}
	
	ConsEx(int i,int j){
//		this();
		System.out.println("Parameterized");
	}
	
	ConsEx(){
		this(10,20);
		System.out.println("Deault");
		
	}

}
