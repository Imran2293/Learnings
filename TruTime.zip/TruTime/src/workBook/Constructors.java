package workBook;

public class Constructors {

	public static void main(String[] args) {
		
		Constructors cs = new Constructors(10,20);

	}
	
	public Constructors(){
		System.out.println("Default Constructors");
	}
	
	public Constructors(int i){
		this();// Invoking Default Constructors using "this" keyword
		System.out.println("Single Parameter Constructor");
	}

	public Constructors(int i,int j){
		this(j);// Invoking Single Parameter Constructor using "this" keyword
		System.out.println("Double Parameter Constructor");
	}
}
