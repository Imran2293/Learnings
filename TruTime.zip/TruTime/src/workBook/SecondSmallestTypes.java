package workBook;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class SecondSmallestTypes {

	public static void main(String[] args) {
		
		Integer[] numbers = {200,40,30,10,50};
//		Arrays.sort(numbers);
//		
//		System.out.println(numbers[1]);
//		
		int smallest,secondsmallest;
		
		smallest = Integer.MAX_VALUE;
		secondsmallest = Integer.MAX_VALUE;
		
		for(int i=0; i<numbers.length; i++){
			
			if(numbers[i]<smallest){
				secondsmallest = smallest;
				smallest = numbers[i];
			}
			
			else if(numbers[i]<secondsmallest){
				secondsmallest = numbers[i];
			}
			

	}
		System.out.println("smallest"+smallest+" "+"secondsmallest"+ secondsmallest);
		
		
//		List<Integer> list = Arrays.asList(numbers);
//		Collections.sort(list);
//		
//		System.out.println(list.get(1));
		
	}
		
		
}
