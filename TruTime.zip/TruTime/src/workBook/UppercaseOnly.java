package workBook;

public class UppercaseOnly {

	public static void main(String[] args) {
		
		String str = "1imR2An@Hu3Cs3Bin";
		for(int i=0;i<str.length();i++){
			if(Character.isDigit(str.charAt(i))){
			if(Character.isUpperCase(str.charAt(i+1))){
			System.out.println(str.charAt(i+1));
			}
			}
		}
		
	}

}
