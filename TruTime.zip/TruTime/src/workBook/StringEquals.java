package workBook;

public class StringEquals {

	public static void main(String[] args) {
		
		String s1="String";
		String s2="String";
		String s3= new String("String");
		
		
		System.out.println(s1==s2);
		System.out.println(s1==s3);
		System.out.println(s1.equals(s2));
		System.out.println(s1.equals(s3));
		
		String s4="String4";
		s4="String5";
		s4="String6";
		
//		String s1="I am Java Expert";
		s1="I am C Expert";
		s1="I am Spring Expert";
		
//		System.out.println(s4);

	}

}
