package workBook;

public class Armstrong {
	
	static int n=153,sum=0,r,temp;
	
	public static void main(String[] args) {
		
		//		while(n>0){
//			r=n%10;
//			sum+=(r*r*r);
//			n=n/10;
//			
//			}
		Armstrong.SumofCubes(n);

		if(sum==temp){
			System.out.println("Armstrong");
		}
		else{
			System.out.println("Not an Armstrong");
		}
	}
	
	
	public static int SumofCubes(int num){
		
		temp = n;
		if(num==0){
			return 0;
		}
		else{
			while(num>0){
			num=num%10;
			sum+=(r*r*r);
			num=num/10;
			}
			return sum;
		}
	}

}
