package workBook;

public class LettersNexttoDot {

	public static void main(String[] args) {
		
		String str = "Imran.Hussaisn.M";
		int indexOf = str.indexOf('n',6);
		int indexOf2 = str.indexOf('s', 10);
		System.out.println(indexOf);
		System.out.println(indexOf2);
		String substring = str.substring(str.indexOf(".")+1);
		
		System.out.println(substring);

	}

}
