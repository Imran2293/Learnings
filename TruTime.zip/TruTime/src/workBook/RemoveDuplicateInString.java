package workBook;

import java.util.Arrays;

public class RemoveDuplicateInString {

	public static void main(String[] args) {
		
		String str = "Alaaddin";
		char[] charArray = str.toCharArray();
		Arrays.sort(charArray);
		for(int i=0; i<charArray.length-1;i++){
			if(charArray[i]==charArray[i+1]){
				System.out.println(charArray[i]);
			}
		}
		
		//In Numbers
		int[] num = {1,2,2,33,3,4,1,5,33};
		for(int i=0;i<=num.length-1;i++){
			for(int j=i+1;j<=num.length-1;j++){
				if(num[i]==num[j]){
					System.out.println(num[i]);
				}
			}
		}

	}

}
