package workBook;

import java.util.Arrays;
import java.util.Collections;

public class SortArray {

	public static void main(String[] args) {
		
		Integer[] arr = {34,22,344,32,45,434,63,322,11};
		Arrays.sort(arr);// Ascending sort
		Arrays.sort(arr,1,7); // Sort Subarray
		//we have Integer here instead of 
        //int[] as Collections.reverseOrder doesn't 
        // work for primitive types. 
		Arrays.sort(arr,Collections.reverseOrder()); // Descending order
		System.out.println(Arrays.toString(arr));
		
		String[] arr1 = {"Imran Hussain","Akilesh","Vaagee","Felix"};
		Arrays.sort(arr1,0,3);
		for(String each:arr1){
		System.out.println(each);
		}
		
		
		//Sort without using Arrays.sort
		int temp;
		int[] array = {4,3,22,11,43,221,21,33,21};
		for(int i=0;i<=array.length-1;i++){
			for(int j=0;j<=array.length-2; j++){
				if(array[j]<array[j+1]){
					temp=array[j];
					array[j]=array[j+1];
					array[j+1]=temp;
				}
			}
		}
		
		System.out.println();
		for(int each:array){
			System.out.print(each+" ");
		}
	}

}
