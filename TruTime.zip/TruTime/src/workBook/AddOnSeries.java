package workBook;

public class AddOnSeries {

	public static void main(String[] args) {
		
		int n=1,i,temp;
		
		for(i=0; i<=10; i++){
			
			n=n+i;
			temp=n;
			System.out.println(temp);
		}

	}

}
