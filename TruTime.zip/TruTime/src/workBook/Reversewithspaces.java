package workBook;

public class Reversewithspaces {

	public static void main(String[] args) {
		
		  String name = "Welcome to Maveric";
	      String strArray[] = name.split(" ");
	      StringBuffer sb= new StringBuffer(name);
	      sb.reverse();
	      for(int i=0; i<name.length(); i++){
	    	  if(name.charAt(i)==' '){
	    		  sb.insert(i, " ");
	    	  }
	      }
	      
	   sb.append("");
	   System.out.println(sb);

	}

}
