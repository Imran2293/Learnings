package workBook;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

public class RemoveDuplicates {

	public static void main(String[] args) {
		
		int[] array = {2,5,4,3,2,7,81,2};
		int count = 0;
//		
//		for(int i=0; i<array.length; i++){
//			for(int j=i+1; j<array.length; j++){
//				if(array[i] == array[j]){
//					count++;
//					
//				}
//			}
//			
//			if(count==1){
//				System.out.println(array[i]);
//				count = 0;
//			}
//		}
		
		// Identify Duplicate
//		int n=array.length;
//		Set<Integer> dupNumbers = new LinkedHashSet<Integer>();
//		for(int i=0;i<n;i++) {
//			for(int j=i+1;j<n;j++) {
//				if(array[j]==array[i]) {
//					dupNumbers.add(array[i]); 
//				}
//			}
//		}
//		System.out.println(dupNumbers);
//		System.out.println();
		
		//Remove Duplicates using SET
		
		Set<Integer> set1 = new LinkedHashSet<Integer>();
		for(int i=0; i<array.length; i++){
			set1.add(array[i]);
		}
		
		Object[] array2 = set1.toArray();
		for(int j=0; j<array2.length; j++){
			System.out.println(array2[j]);	
		}
		
		

	}

}
