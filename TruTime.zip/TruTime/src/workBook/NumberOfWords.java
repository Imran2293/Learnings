package workBook;

public class NumberOfWords {

	public static void main(String[] args) {
		
		String str = "India USA UK Russia";
		int count=0;
		for(int i=0; i<str.length();i++){
			if(str.charAt(i)==' '){
				++count;
			}
		}
		
		System.out.println("Number of words in a String: "+ (count+1));

	}

}
