package workBook;

public class Series {

	public static void main(String[] args) {
		
		int a = 1;
		for(int i=0;i<10;i++){
			a+=i;
			System.out.print(a+" ");
		}

	}

}
