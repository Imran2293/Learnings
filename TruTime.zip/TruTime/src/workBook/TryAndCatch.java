package workBook;

public class TryAndCatch {

	public static void main(String[] args) {
		
		try{
			int x=0;
			int y = 5;
			int z=y/x;
			
		}
		catch(ArrayIndexOutOfBoundsException aiou){
			System.out.println("False exception");
		}
		
		
		catch(Exception e)
		{
			System.out.println("exception");
		}
		catch(ArithmeticException ae){
			System.out.println("Arithmetic Exception");
			
		}
	}

}
