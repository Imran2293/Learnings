package workBook;

public class AbstractDemo {

	
		public static void main(String[] args) {
			
		Employee e = new Employee("George","Houston",43);
		System.out.println("\n Call mail check using employee reference");
		e.mailCheck();
			

		}

	}

