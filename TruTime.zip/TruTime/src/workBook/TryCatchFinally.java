package workBook;

public class TryCatchFinally {

	public static void main(String[] args) {
		
		System.out.println(TryCatchFinally.method1());
	}
		
	public static int method1(){
		
	
		try{
			
			return 112;
		}
		catch(Exception e){
			
			System.out.println("Exception statement");
		}
		
		finally{
			System.out.println("Begin Finally");
			System.out.println("Finally executes");
		}
		return 112;
	}
	}


