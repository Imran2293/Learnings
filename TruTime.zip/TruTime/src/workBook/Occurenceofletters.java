package workBook;

import java.util.HashMap;
import java.util.Map;

public class Occurenceofletters {

	public static void main(String[] args) {
		
		String str = "Cognizant Technology Solutions";
		char[] CA = str.toCharArray();
		Map<Character,Integer> CharCount = new HashMap<Character,Integer>();
		
		for(char each:CA){
		
			if(CharCount.containsKey(each)){
				CharCount.put(each, CharCount.get(each)+1);
			}
			else
			{
				CharCount.put(each, 1);
			}
			
		}
		
		
		System.out.println(CharCount);
		
		String someString = "elephant";
		char someChar = 'e';
		int count = 0;
		  
		for (int i = 0; i < someString.length(); i++) {
		    if (someString.charAt(i) == someChar) {
		        count++;
		    }
		}
		System.out.println(someChar+" "+count);

	}

}
