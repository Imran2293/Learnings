package workBook;

public class SumofDigitsNumber {

	public static void main(String[] args) {
		
//		int n=255,sum=0,r;
//		while(n>0){
//			r=n%10;
//			sum+=r;
//			n=n/10;
//			
//		}
//		System.out.println(sum);
		
		int num=1111;
		int result = sumOfDigits(num);
		System.out.println(result);
	}
	
	static int sumOfDigits(int n){
		
		if(n==0){
			return 0;
		}
			else{	
			return(n%10 + sumOfDigits(n/10));
			
		
		}
		
				
	}

}
