package workBook;

import java.util.Arrays;

public class MaxnMin {

	public static void main(String[] args) {
		
		int[] arr = {23,1,33,25,65,34};
		Arrays.sort(arr);
//		System.out.println("Smallest Number is: "+ arr[0]);
//		System.out.println("Largest Number is: "+ arr[arr.length-1]);
		
		//using for loop
		int largest=arr[0];
		int smallest=arr[0];
		for(int i=0; i<arr.length;i++){
			if(arr[i]<smallest){
				smallest=arr[i];
			}
			else if(arr[i]>largest){
				largest=arr[i];
			}
		}
		
		System.out.println("Smallest: "+smallest);
		System.out.println("Largest: "+largest);

	}

}
