package workBook;

import org.openqa.selenium.support.ui.Select;

public class PrintTriangles {

	public static void main(String[] args) {
		
		int n=9,i,j;
		
		for(i=0; i<n; i++){
			for(j=0; j<=i; j++){
				System.out.print("* ");
			}
		}
		
		System.out.println();
		
//		Select sl = new Select(driver.findElementByXpath("//select[@id='dropdown1']"));
//		sl.se
	}

}
