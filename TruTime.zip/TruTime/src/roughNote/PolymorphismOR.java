package roughNote;

public class PolymorphismOR {

	private static void main(String[] args) {
		
//		Parent1 ch = new Child();
//		ch.method1();
		
		Parent1 ch = new Child1();
//		Parent1 pa = new Parent1();
		
//		pa.method1();
//		pa.method2();
//		pa.method3();
//		ch.method1();
//		
		ch.method2();
//		ch.method3();
		ch.method1();
		ch.method3(3);

	}

}
//The public type Parent1 must be defined in its own file
class Parent1{
	
	 void method1(){
		System.out.println("method1 result");
	}
	
	public static void method2(){
		System.out.println("method2 result");
	}
	
	public void method3(int i){
		System.out.println("method3 result");
	}
}

class Child1 extends Parent1{
	
	public void method1(){
		System.out.println("method4 result");
	}
	
	public static void method2(){
		System.out.println("method5 result");
	}
	
	public final void method3(){
		System.out.println("method6 result");
	}
	
	public final void method3(int a){
		System.out.println("method3 overload"+a);
	}
}
