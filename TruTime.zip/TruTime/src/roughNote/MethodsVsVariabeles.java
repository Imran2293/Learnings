package roughNote;

public class MethodsVsVariabeles {

	public static void main(String[] args) {

		MethodsVsVariabeles mv = new MethodsVsVariabeles();
		
		byte z=7;
		
//		byte y= (byte) mv.method1(x);
		
//		System.out.println(y);
		
		int[] arr = mv.method1(5);
		
		for (int i : arr) {
			System.out.println(i);
		}
		
				
	}
	
	int[] method1(int z){
		
		int[] arr1 ={1,2,3};
		
		return arr1;
	}
	
	int method2(int z){
		
		return z;
	}

}
