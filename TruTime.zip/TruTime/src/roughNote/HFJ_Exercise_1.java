package roughNote;

import org.eclipse.wst.wsdl.ui.internal.asd.design.figures.HeadingFigure;

public class HFJ_Exercise_1 {

	public static void main(String[] args) {

		int orig = 42;
		
		HFJ_Exercise_1 obj1 = new HFJ_Exercise_1();
		
		int y = obj1.method1(orig);
		
		System.out.println(orig+" "+ y);
		
		
	}
	
	int method1(int arg){
		
		arg = arg*2;
		
		return arg;
		
	}

}
