package roughNote;

public class ArrayVSArrayList {

	public static void main(String[] args) {

		String[] myList = new String[2];
		
		String a = new String("Value 1");
		String b = new String("Value 2");
		
		myList[0] = a;
		myList[1] = b;
		
		int size = myList.length;
		
		String get = myList[0];
		
//		myList[0]="";
		
		boolean ifExists = myList[0].contains("Value 1");
		
		
		
		
		
		for(String each: myList){
			
			System.out.println(each);
			
		}
		
		System.out.println(size+" "+get+" "+ifExists);
	}

}
