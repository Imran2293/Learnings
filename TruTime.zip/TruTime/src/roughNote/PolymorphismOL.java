package roughNote;

public class PolymorphismOL {

	public static void main(String[] args) {
		
		

	}

}
