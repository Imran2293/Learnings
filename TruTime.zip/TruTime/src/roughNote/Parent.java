package roughNote;

public class Parent {
//	public Parent() 
//    { 
//		System.out.println("Parent");
//    } 
  
	public Parent(int x) 
    { 
		System.out.println("Parent");
    } 
    public void print() 
    { 
    } 
    
    public static void main(String[] args) 
    { 
        Child c1 = new Child(0); // allowed 
        Child c2 =  (Child) new Parent(0); // not allowed 
    } 
} 
  
 class Child extends Parent { 
    public Child(int y) 
    { 
    	super(y);
    	System.out.println("Child");
    } 
    public void print() 
    { 
    } 
  
   
}
