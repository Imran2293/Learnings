package roughNote;

import org.eclipse.wst.wsdl.ui.internal.asd.design.figures.HeadingFigure;

class Tester {

	String time;
	
	void setTime(String t){
		
		time = t;
	}
	
	String getTime(){
		
		return time;
	}
}

class  HFJ_Exercise_2{
	
	public static void main (String args[]){
		
		Tester ts = new Tester();
		ts.setTime("20:30 PM");
		
		String timenow = ts.getTime();
		
		System.out.println("Time Now is "+ timenow);
		
	}
}
