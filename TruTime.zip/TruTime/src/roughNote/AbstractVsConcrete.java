package roughNote;

import java.util.ArrayList;

public class AbstractVsConcrete extends Object {

	public static void main(String args[]){
		
		Animal obj1 = new Dog();
		obj1.method1();
		obj1.method2();
		obj1.method3();
		
		ArrayList<Object> myList = new ArrayList<Object>();
		
		Dog1 d = new Dog1();
		
		myList.add(d);
		
		Object object = myList.get(0);
		
		ArrayList<Dog1> myList2 = new ArrayList<Dog1>();
		
		myList2.add(d);
		
		Dog1 dog1 = myList2.get(0);
		
		
		
		
	}
}

class Dog1{
	
}

abstract class Animal{
	
	abstract void method1();
	abstract void method2();
	
	void method3(){
		System.out.println("Concrete method of Abstract Class Animal");
	}
}

abstract class Canines extends Animal {
	
	@Override
	void method1(){
		System.out.println("Abstract Method 1 of Animal Class");
	}
	
}

class Dog extends Canines{

	@Override
	void method2() {
		System.out.println("Abstract Method 2 of Animal Class");
		
	}

	void method3(){
		System.out.println("Concrete Overridden Method of Animal Class");
	}
	
}