package roughNote;

import org.openqa.selenium.support.Color;

public class Bla {

	private final Color color;

    public Bla(Color c) {
    	this.color = c;
    			
    }
    
    public Bla(Color d,Color e){
    	this.color=d;
    	
    }
    
    
}
