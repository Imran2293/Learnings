package roughNote;

public class InA {

	int varA;
	void methodInA(){
		System.out.println("Method InA Called");
	}
	

}


class InB extends InA {
	
	void methodInB(){
		System.out.println("Method InB Called");
	}
	
	
//	InB ba = new InA();
	
	
}

class InC{
	
	public static void main(String args[]){
		InA a = new InA();
		InB b = new InB();
		InA ab = new InB();
		
		a.methodInA();
		b.methodInA();
		b.methodInB();
		ab.methodInA();
//		b.varA=5;
//		a.varA=b.varA;
//		
//		System.out.println(a.varA);
	}
}