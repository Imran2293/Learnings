package roughNote;

class MainClass  {

	private int size = 10;
	
	public int getSize(){
		
		return size;
		
	}
	
	public void setSize(int s){
		
		System.out.println("Original value of Instance variable Size "+ size);
		
		size = s;
		
		System.out.println("New value of Instance variable Size "+ size);
	}
	
}

class Encapsulation {
	
	public static void main(String args[]){
		

		MainClass mc = new MainClass();
		mc.setSize(20);
		
	}
}