package roughNote;

public class SeriousPolyMorphism {

}

abstract class Abstract{
	
	void methodAbs(){
		System.out.println("Abstract Method");
	}
	
	abstract void abstractMethod();
}

class Normal extends Abstract	{
	
	Abstract a  = new Normal();
	
	
	public void go(){
		a.methodAbs();
	}


	@Override
	void abstractMethod() {
		// TODO Auto-generated method stub
		
	}
}


