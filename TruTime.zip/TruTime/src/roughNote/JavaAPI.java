package roughNote;

import java.util.ArrayList;

public class JavaAPI {
	
	public static void main (String args[]){
		
		ArrayList<Object> myList = new ArrayList<Object>();
		
		String s = new String();
		
		myList.add(s);
		
		String b = new String();
		
		myList.add(b);
	
		
		String sb = null;

		int sizeOfList = myList.size();
		
		boolean ListContains = myList.contains(b);
		
		int indexOf = myList.indexOf(s);
		
		boolean isEmpty = myList.isEmpty();
		
		System.out.println(sizeOfList+" "+ListContains+" "+indexOf+" "+isEmpty);
		
	}

}
