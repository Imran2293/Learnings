package roughNote;

public class SimpleDotComTestDrive {

	public static void main(String[] args) {

		SimpleDotCom sdc = new SimpleDotCom();
		int[] locations = {1,2,3};
		sdc.setLocationCells(locations);
		String userGuess = "1";
		String result = sdc.checkYourSelf(userGuess);
		
	}

}

class SimpleDotCom{
	
	int[] locationCells;
	int numberOfHits = 0;
	
	void setLocationCells(int[] locs){
		locationCells = locs;
	}
	
	String checkYourSelf(String guess){
		
		int guessint = Integer.parseInt(guess) ;
		String result = "miss";
		for(int cell: locationCells){
			if(guessint == cell){
				
				result = "hit";
				numberOfHits++;
				break;
			}
		}
		
		if(numberOfHits == locationCells.length){
			
			result ="kill";
		}
		
		System.out.println("Result: "+ result);
		return result;
		
	}
	
	
}
