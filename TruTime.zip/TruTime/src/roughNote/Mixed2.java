package roughNote;

public class Mixed2 {

	public static void main(String[] args) {

		A2 a = new A2();
		B2 b = new B2();
		C2 c = new C2();
		A2 a2 = new C2();
		
		a2.m1();
		a2.m2();
		a2.m3();
	}

}

class A2{
int ivar = 7;
	
	void m1(){
		System.out.println("A's m1");
	}
	
	void m2(){
		System.out.println("A's m2");
	}

	void m3(){
		System.out.println("A's m3");
	}

}

class B2 extends A2 {
	void m1(){
		System.out.println("B's m1");
	}
	
	void m2(){
		System.out.println("B's m2");
	}
}

class C2 extends B2 {
	
	void m3(){
		System.out.println("C's m3 "+ (ivar+6) );
	}
}
