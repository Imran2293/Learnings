package roughNote;

public class PlaySongs {

	String artist;
	String title;

	// Objects have State and Behaviour

	public static void main(String[] args) {

		PlaySongs t1 = new PlaySongs();
		PlaySongs s1 = new PlaySongs();
		t1.SetArtist("Alex");
		t1.SetTitle("Maasi Maasam");
		t1.Play();
		s1.SetArtist("Jegan");
		s1.SetTitle("Harris Mashup");
		s1.Play();

	}

	void Play() {
		System.out.println("Song Title= "+ title+" Artist= "+ artist);
	}

	void SetTitle(String title) {

		this.title = title;

	}

	void SetArtist(String artist) {

		this.artist = artist;

	}
}
