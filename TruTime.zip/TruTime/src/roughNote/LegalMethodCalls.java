package roughNote;

public class LegalMethodCalls {

	public static void main(String[] args) {

		LegalMethodCalls lmc = new LegalMethodCalls();
		
		int a = calcArea(4,7);
		
		short c = 7;
		
		calcArea(c, 7);
		
		calcArea(7, 5);
		
		long t = 72;
		
		calcArea((int) t, 23);
		
		byte h = (byte) calcArea(45, 23);
	}
	
	public static int calcArea(int height, int width){
		
		return height*width;
	}

}
