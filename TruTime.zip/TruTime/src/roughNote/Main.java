package roughNote;

public class Main {

	public static void main(String[] args) {
		
//		A.fun();
//		B.fun();
		
		A a = new B();
		a.fun();
		a.fun2();
		
		
		
//		B b = new B();
//		b.fun();
//		b.fun2();
	
		
//		A c = new A();
//		c.fun();

	}

}

class A{
	 void fun(){
		System.out.println("A.fun");
	}
	 void fun2(){
		 System.out.println("A.fun2");
	 }
	 void fun3(){
		 System.out.println("A.fun3");
	 }
}

class B extends A{
	 void fun(){
		System.out.println("B.fun");
	}
	 
	 void fun2(){
		 System.out.println("B.fun2");
	 }
}
