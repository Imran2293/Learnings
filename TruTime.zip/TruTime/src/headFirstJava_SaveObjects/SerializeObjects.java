package headFirstJava_SaveObjects;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class SerializeObjects implements Serializable {
	
	int width = 35;
	int height = 45;

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
		SerializeObjects so = new SerializeObjects();
		so.getWidth();
		so.getHeight();
		
		SerializeObjects so2 = new SerializeObjects();
		so2.getWidth();
		so2.getHeight();
		
		Sub su = new Sub();
		su.getLength();
		
		FileOutputStream fos = new FileOutputStream("MyGames.txt");
		
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		oos.writeObject(so);
		oos.writeObject(so2);
		oos.writeObject(su);
		
		oos.close();
		
		FileInputStream fis = new FileInputStream("MyGames.txt");
		ObjectInputStream ois = new ObjectInputStream(fis);
		
		SerializeObjects obj1 = (SerializeObjects) ois.readObject();
		SerializeObjects obj2 = (SerializeObjects) ois.readObject();
		Sub obj3 = (Sub)ois.readObject();
		
		
		
		System.out.println(obj1.getWidth()+" "+ obj1.getHeight());
		System.out.println(obj2.getWidth()+" "+ obj2.getHeight());
		System.out.println(obj3.getClass()+" "+ obj3.getLength());
	
		
	}
	
	public int getWidth(){
		return width;
	}
	
	public int getHeight(){
		return height;
	}

}

class Sub implements Serializable {
	
	int length;
	
	int getLength(){
		return length;
	}
}
