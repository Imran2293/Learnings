package headFirstJava_SaveObjects;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class MakeConnection {

	public static void main(String[] args) throws UnknownHostException, IOException {

		MakeConnection mc = new MakeConnection();
		mc.writeData();
		mc.readData();
	}

	void writeData() throws UnknownHostException, IOException {

		@SuppressWarnings("resource")
		Socket conn = new Socket("localhost", 4242);

		PrintWriter pwr = new PrintWriter(conn.getOutputStream());

		pwr.write("New String 1 Value");
		
		pwr.write("New String 2 Value");

		pwr.close();
	}

	void readData() throws UnknownHostException, IOException {

		@SuppressWarnings("resource")
		Socket conn = new Socket("localhost", 4242);

		InputStreamReader isr = new InputStreamReader(conn.getInputStream());

		BufferedReader reader = new BufferedReader(isr);

		String line = null;
		line = reader.readLine();
		System.out.println(line);
	}

}
