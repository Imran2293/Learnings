package headFirstJava_SaveObjects;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileRead_Write {

	File file = new File("SimpleTextFile.txt");
	FileWriter writer;
	FileReader reader;
	
	public static void main(String[] args) throws IOException {

		FileRead_Write frw = new FileRead_Write();
		frw.writeFile();
		frw.readFile();
			
	}

	
	void writeFile() throws IOException{
		

		writer = new FileWriter(file);
			
		BufferedWriter bwriter = new BufferedWriter(writer);
		
		bwriter.write("This is a sample document for Buffered Writer");
		bwriter.newLine();
		bwriter.write("This statement is written in a new line");
		bwriter.append(" Appended Value");
		
		bwriter.close();
		
		
		
	}
	void readFile() throws IOException{
		
		reader = new FileReader(file);
		
		BufferedReader breader = new BufferedReader(reader);
		
		String LineRead = null;
		
		while((LineRead = breader.readLine()) != null){
			
			System.out.println(LineRead);
		}
		
		breader.close();
		
		
	}
}
