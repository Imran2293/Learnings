package cummins;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DocumentControlSample {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\rj815\\Selenium\\Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.navigate().to("https://rj815:Livelong@01@cummins365.sharepoint.com/sites/"
				+ "GRP_CQMS00093/Lists/DocumentControl/Form%20Control%20Docs.aspx");
		driver.manage().window().maximize();
		
		//Select DC dropdown
//		driver.findElement(By.xpath("(//i[@data-icon-name='ChevronDown'])[1]")).click();
//		
//		driver.findElement(By.xpath("//*[text()='Form Control Docs']")).click();
		
		driver.findElementByXPath("//*[text()='Create Document']").click();
//		driver.manage().timeouts().implicitlyWait("", arg1)
				
//		WebElement create = driver.findElement(By.linkText("Create Document"));
//		
//		WebDriverWait wait = new WebDriverWait(driver,20);
//		wait.until(ExpectedConditions.elementToBeClickable(create));
//		
//		create.click();
		
		driver.findElementByXPath("//*[text()='Form Control Document']").click();
		
		driver.findElementByXPath("//*[text()='Customized Content Form']").click();

		driver.findElementByXPath("//*[text()='OK']").click();

		//*[text()='OK']

		//*[text()='Customized Content Form']
		
		
		
	}

}
