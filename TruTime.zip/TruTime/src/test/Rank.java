package test;

public class Rank {

	public static void main(String[] args) {
		
		int rating = 6;
		String level;
		
		if (rating == 1) {
			      level = "novice";
			  } else if (rating == 2) {
			      level = "beginner";
			  } else if (rating == 3) {
			      level = "moderate";
			  } else if (rating == 4) {
			      level = "advanced";
			  } else {
			      level = "expert";
			  }
			  System.out.println("Experience level: " + level);

	}

}
