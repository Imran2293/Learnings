package test;

public class Sum {

	public static void main(String[] args) {
		int a=4;
		int b=6;
		int c=1;
		
//		int ans = ++c+b%a-(c-b*c);
//		int ans = a*b- ++c*b;
//		int ans = (c-b)*(a/++c);
//		int ans = ++b+b%a-c-b*c;
		int ans = (-c*b++*(a-b))-4;
		System.out.println(ans);
	}

}
