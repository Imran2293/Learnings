package test;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebTable {
	
	ExtentReports extent; 

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\rj815\\Selenium\\Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://leafground.com/");
		driver.findElementByXPath("//h5[text()='Table']").click();
		List<WebElement> list = driver.findElementsByXPath("//table[@id='table_id']/tbody/tr/td[text()='Koushik']/../td[6]");
		for (WebElement each : list) {
			System.out.println(each.getText());
		}
		List<WebElement> list2 = driver.findElementsByXPath("//table[@id='table_id']/tbody/tr[last()]/td");
		for (WebElement each2 : list2) {	
			System.out.println(each2.getText());
		}
	}

}
