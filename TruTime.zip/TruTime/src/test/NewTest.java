package test;

//public class ReplaceAll {
//
//	public static void main(String[] args) {
//		
////		String name = "Imran Hussain";
////		String newName = name.replace("a", "*");
////		System.out.println(newName);
////		
////		for(int i=1; i<=10; i++){
////			for (int j = 1; j <=i ; j++) {
////				if(i%2 !=0){
////					System.out.print("*");
////				}
////			}
////			System.out.println();
////		}
//		
//		String name = "ImraN HusSain";
//		char[] charArray = name.toCharArray();
//		String substring = name.substring(2, 10);
//		System.out.println(substring);
//		for (char c : charArray) {
//			if(Character.isUpperCase(c)){
//				System.out.print(Character.toLowerCase(c));
//			}
//			else{
//				System.out.print(Character.toUpperCase(c));
//			}
//		}
		
//		String concat = name.concat(" Mohammed");
//		System.out.println(concat);
//		int[] arr;
//		int arr1[];
//		
//		StringBuffer sb = new StringBuffer("Imran Hussain");
//		sb.append(" Mohammed");
//		System.out.println(sb);
//		System.out.println(sb.substring(22));
//		sb.reverse();
//		System.out.println(sb);
		
//        int arr2[][] = { {2,7,9},{3,6,1},{7,4,2} }; 
//        for (int i=0; i< 3 ; i++) 
//        { 
//            for (int j=0; j < 3 ; j++) 
//                System.out.print(arr2[i][j] + " "); 
//  
//            System.out.println(); 
//        } 
        
//        String h1 = "Hello";
//        h1 = "Hello"+"World";
//        System.out.println(h1);
//        
//        String h2 = "Hello";
//        String h3 = "Hello";
//        String h4 = "Hello";
//        
//        System.out.println(h4);
        

class Foo {
    public static void method() {
        System.out.println("in Foo");
    }
}
 
class Bar extends Foo {
    public static void method() {
        System.out.println("in Bar");
    }
}

class NewTest {
	
public static void main(String[] args) {
 
        Foo.method();
        Bar.method();
    }
//}

		
		
		
		
		
		
		
		}

	}


