package test;

import oneCog.ChangeOddIndex;

public class A  {

	public static void main(String[] args) {
		
		A aClass = new A();
		A aClass2 = aClass;
		if(aClass==aClass2)
		{
			System.out.println("objs ara eql");
		}
		else
		{
			System.out.println("not");
		}
		
		
//		System.out.println(MyTest.myWar);
		
//		String myName = "Imran Hussain";
//		myName.intern();
		
//		int x=0;
//		while(x<5)
//		{
//			System.out.println(x);
//		}
		
		
	}
	
	}
	
//	int Inter(int x, int y){
//		return x+y;
//	}




