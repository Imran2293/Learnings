package test;

public class Try {

	public static void main(String[] args) {
		int a=0;
		try{
			a=5/0;
			System.out.println("Isider a");
		}catch(ArithmeticException ae){
			System.out.println("Cannot");
			System.out.println();
		}
		System.out.println("Oustide");

	}

}

/*
 * . class MakeVertebrates {
02.    public static void main(String[] args) {
03.       Vertebrate whiteCat = new Cat();
04.       Cat blackCat = new Cat();
05.       Cat strayCat = new Cat();
06.       strayCat = whiteCat;
07.       blackCat = strayCat;
08.    }
09. }
10. class Vertebrate { }
11. class Cat extends Vertebrate { }*/
 * 
