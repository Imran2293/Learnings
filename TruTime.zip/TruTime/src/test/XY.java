package test;

public class XY {

	public static void main(String[] args) {
		
		int x=7;
		int y=0;
		while(x>4 | y<3){
			x--;
			y++;
		}
		
		System.out.println(x + ""+ y);

	}
	
	Employee emp = new Manager();

}
