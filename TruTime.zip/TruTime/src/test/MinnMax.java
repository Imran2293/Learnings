package test;

import java.util.Arrays;
import java.util.Collections;

public class MinnMax {

	public static void main(String[] args) {
		
		Integer[] arr={15,125,373,22,6854,12};
		
		Integer max = Collections.max(Arrays.asList(arr));
		System.out.println(max);
		Integer min = Collections.min(Arrays.asList(arr));
		System.out.println(min);

	}

}
