package test;

public class MyTest {

	public static void main(String[] args){
		Foo.method();
        Bar.method();
	}
	
}

class Foo {
    public final void method() {
        System.out.println("in Foo");
    }
}
 
class Bar extends Foo {
    public static void method() {
//        System.out.println("in Bar");
    }
}

