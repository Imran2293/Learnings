package test;


//		int x=0;
//		while(true){
//			System.out.println(x+" ");
//			x=x+2;
//			if(x>6){
//				break;
//			}
//		}
		
//		int x=3;
//		int y=2;
//		int z=4;
//		int total = (x++ + ++x)*(y-z);
//		System.out.println(total
//				);

//		StringBuilder sb = new StringBuilder("Test");
//		StringBuilder test = sb.append("StringBuilder");
//		System.out.println(test);
		
//		public static void main(String[] args) {
//			         int x = 2;
//			         System.out.println("x squared = " + squareNumber(x));
//			         System.out.println("x = " + x);
//			     }
//			 
//			     public static int squareNumber(int x) {
//			         x = x * x;
//			         return x;
//			     }
//			 }
	

//		import java.io.*;
//	 public class MyClass {
//			 
//			 static int myWar = 2;
//		    public static void main(String[] args) {
//		    	System.out.println(myWar);
////		       MyClass myClass = new MyClass();
////		       try {
////		          myClass.getFile();
////		          System.out.println("Exit getFile method");
////		       }
////		       catch(IOException e) {
////		          System.out.println(e.getMessage());
////		       }
////		    }
////		    void getFile() throws FileNotFoundException {  
////		       // code to open a file
////		       throw new FileNotFoundException("Error: File Not Found");
////		       System.out.println("Open the file");
//		    	
//		    	
//		    }
//		 }

//public class Test{
//	public static void main (String args[][]){
//		Employee myManager = new Manager();
//		Manager myExec = new Ex();
//	}
//}
//
//class Employee{}
//class Manager extends Employee{}
//class Ex extends Employee{}
	
//class A {
//      public void getMessage() {
//          System.out.println("In class A");
//      }
//  }
//
//  class B extends A {
//      public void getMessage() {
//          System.out.println("In class B");
//      }
// }
//
//  class Tester {
//      public static void main(String[] args) {
//          A a1 = new A();
//          B b1 = new B();
//          a1 = b1;
//          B b2 = a1;
//          a1.getMessage();
//          b2.getMessage();
//      }
//  }
//		 int i =0;
//		 while(i<=10){
//			 if(i)
//		 }

		 class MakeVert {
			     public static void main(String[] args) {
//			        Vertebrate whiteCat = new Cat();
//			        Vertebrate blackCat = new Cat();
//			       Vertebrate strayCat = new Cat();
//			        strayCat = whiteCat;
//			        blackCat = strayCat;
			    	 
			    	 String name1 = new String("Java"); 
			    	 String name2 = new String("Java"); 
			    	     
			    	 if (name1 == name2) {    
			    	     System.out.println("Objects are equal"); 
			    	 } else {
			    	     System.out.println("Objects are not equal"); 
			    	 }   

			    	 if (name1.equals(name2)) {   
			    	     System.out.println("Objects are equal"); 
			    	 } else {
			    	     System.out.println("Objects are not equal"); 
			    	 }

			     }
			  
//			  class Vertebrate { }
//			  class Cat extends Vertebrate { }
	 }
	 
	 
