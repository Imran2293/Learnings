package test;

public class Looping {
     public static void main(String[] args) {
        int x = 0;
         int i = 0;
         for ( ; i < 5; i++) { 
             x++;
             if (x == 3) {
                 break; 
            }
         }
        System.out.println("x is: " + x);       
        System.out.println("i is: " + i);
    }
}

  



