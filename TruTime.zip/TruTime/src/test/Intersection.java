package test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Intersection {

	public static void main(String[] args) {
		
		int[] arr1 = {4,7,5,6};
		int[] arr2 = {5,9,2,4,9};
		
//		List<Integer> al1 = new ArrayList<Integer>();
//		for (Integer each : arr1) {
//			al1.add(each);
//		}
//		
//		List<Integer> al2 = new ArrayList<Integer>();
//		for (Integer each1 : arr2) {
//			al2.add(each1);
//		}
//		
//		al1.retainAll(al2);
//		System.out.println(al1);
		
		List<Integer> ArrayList = new ArrayList<Integer>();
		for (int i = 0; i < arr1.length; i++) {
			for (int j = 0; j < arr2.length; j++) {
				if(arr1[i]==arr2[j]){
					ArrayList.add(arr2[j]);
				}
			}
		}
		Collections.sort(ArrayList);
		System.out.println(ArrayList);
	}

}
