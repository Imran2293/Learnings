package test;

		
		interface One {
			     void firstMethod();
			 }
			 interface Two {
			     abstract void secondMethod();
			 }
			 interface Three extends One, Two {
			     void thirdMethod();
			 }
			 class Four implements Three {
			     public void firstMethod() { 
			         // code here 
			     }
			     public void secondMethod() {
			         // code here
			     }
			     public void thirdMethod() {
			         // code here
			     }
			 

	}


