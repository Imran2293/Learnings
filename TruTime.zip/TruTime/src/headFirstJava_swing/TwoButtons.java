package headFirstJava_swing;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class TwoButtons  {
	
	
	JFrame frame;
	JLabel label;
	
	public static void main(String[] args){
		
		TwoButtons tb = new TwoButtons();
		tb.go();
		
	}
	
	public void go(){
		
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		MyDrawPanel drawPanel = new MyDrawPanel();
		
		JButton LButton = new JButton("Change Label");
		LButton.addActionListener(new LabelListener());

		JButton CButton = new JButton("Change Color");
		CButton.addActionListener(new ButtonListener());

		
		label = new JLabel("I'm a Label");
		
		
		frame.getContentPane().add(BorderLayout.EAST,LButton);
		frame.getContentPane().add(BorderLayout.SOUTH,CButton);
		frame.getContentPane().add(BorderLayout.CENTER,drawPanel);
		frame.getContentPane().add(BorderLayout.WEST,label);
		
		frame.setSize(300,300);
		frame.setVisible(true);
		
	}
	
	class LabelListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			label.setText("I've been Clicked");
		}
		
	}
	
	class ButtonListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {

			frame.repaint();
		}
		
	
	}

}
