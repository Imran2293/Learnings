package headFirstJava_swing;

import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;

public class JTextFields {

	JFrame frame;

	public static void main(String[] args) {

		JTextFields jtf = new JTextFields();
		jtf.go();
	}

	void go() {

		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		frame.getContentPane().add(panel);

		JButton button1 = new JButton("Button in the West");
//		frame.getContentPane().add(BorderLayout.SOUTH,button1);
		panel.add(button1);
		
		// JText Field Methods
		JTextField field = new JTextField("Insert Text in me",10);
		field.setText("Entered values in the text field");
		
		String getText = field.getText();
		System.out.println(getText);
		
		field.selectAll();
	
		panel.add(field);
		
		frame.setSize(300, 300);
		frame.setVisible(true);
		
		String[] listEntries = {"List 1","List 2","List 3","List 4","List 5"};
		JList list = new JList(listEntries);
		
		JScrollPane scroller = new JScrollPane(list);
		scroller.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		
		list.setVisibleRowCount(3);
		panel.add(scroller);
		
		
		
	}
}