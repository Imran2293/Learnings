package headFirstJava_swing;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import java.awt.*;


public class BorderLayoutExercise {

	

	public static void main(String[] args) {

		BorderLayoutExercise bl = new BorderLayoutExercise();
		bl.go();
	}

	public void go() {

		/*JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JButton button = new JButton("Button in the East");
		Font JFont = new Font("serif",Font.BOLD,24);
		button.setFont(JFont);
		frame.getContentPane().add(BorderLayout.EAST, button);
				
		frame.setSize(400, 400);
		frame.setVisible(true);*/

	}
}
