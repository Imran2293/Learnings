package headFirstJava_swing;

public class Panel2 {
	
	

}
