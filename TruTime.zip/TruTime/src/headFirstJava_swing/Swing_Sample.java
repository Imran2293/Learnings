package headFirstJava_swing;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;

public class Swing_Sample {
	
	JFrame frame;
	

	public static void main(String[] args) {
		
		Swing_Sample ss = new Swing_Sample();
		ss.panel_1_CreateGUI();
		ss.panel_2_CreateGUI();
		ss.panel_3_CreateGUT();
	}
	
	public void panel_1_CreateGUI(){
		
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel1 = new JPanel();
		panel1.setBackground(Color.ORANGE);
		panel1.setLayout(new BoxLayout(panel1,BoxLayout.Y_AXIS));
		
		frame.getContentPane().add(BorderLayout.WEST,panel1);
		
		JButton button1 = new JButton("Panel 1 Button");
				
		JLabel lable1 = new JLabel("1. Enter UserName: ");
		JTextField field1 = new JTextField(20);
		field1.setText("John Cena");
		
		JLabel lable2 = new JLabel("2. Enter Password: ");
		JTextField field2 = new JTextField(20);
		field2.setText("******");
		
		panel1.add(lable1);
		panel1.add(field1);
		panel1.add(lable2);
		panel1.add(field2);
		
		JLabel lable3 = new JLabel("3. Description: ");
		JTextArea area1 = new JTextArea(10,20);
		JScrollPane scrollPane = new JScrollPane(area1);
		area1.setLineWrap(true);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		
		panel1.add(lable3);
		panel1.add(scrollPane);
		
		JLabel lable4 = new JLabel("4. Form Types: ");
		String[] forms = {"PCD","FCD","SOP","QP","WI","RD","DC","CR"};
		JList<String> list = new JList<String>(forms);
		
		JScrollPane scroller = new JScrollPane(list);
		scroller.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

		panel1.add(lable4);
		panel1.add(scroller);

		list.setVisibleRowCount(4);

		panel1.add(BorderLayout.SOUTH,button1);

		
		frame.setSize(300,300);
		frame.setVisible(true);

		
		
	}
	
	void panel_2_CreateGUI(){
		
		JPanel panel2 = new JPanel();
		panel2.setBackground(Color.BLUE);
		
		frame.getContentPane().add(BorderLayout.CENTER,panel2);
		panel2.setLayout(new BoxLayout(panel2,BoxLayout.Y_AXIS));

		JButton button2 = new JButton("Panel 2 Button");
		panel2.add(BorderLayout.CENTER,button2);
		
		JLabel lable1 = new JLabel("1. Enter UserName: ");
		JTextField field1 = new JTextField(20);
		field1.setText("John Cena");
		
		JLabel lable2 = new JLabel("2. Enter Password: ");
		JTextField field2 = new JTextField(20);
		field2.setText("******");
		
		panel2.add(lable1);
		panel2.add(field1);
		panel2.add(lable2);
		panel2.add(field2);
		
		JLabel lable3 = new JLabel("3. Description: ");
		JTextArea area1 = new JTextArea(10,20);
		JScrollPane scrollPane = new JScrollPane(area1);
		area1.setLineWrap(true);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		
		panel2.add(lable3);
		panel2.add(scrollPane);
		
		JLabel lable4 = new JLabel("4. Form Types: ");
		String[] forms = {"PCD","FCD","SOP","QP","WI","RD","DC","CR"};
		JList<String> list = new JList<String>(forms);
		
		JScrollPane scroller = new JScrollPane(list);
		scroller.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

		panel2.add(lable4);
		panel2.add(scroller);

		list.setVisibleRowCount(4);

		panel2.add(BorderLayout.SOUTH,button2);


	}
	
	void panel_3_CreateGUT(){
		
		JPanel panel3 = new JPanel();
		panel3.setBackground(Color.GREEN);
		
		frame.getContentPane().add(BorderLayout.EAST,panel3);
		panel3.setLayout(new BoxLayout(panel3,BoxLayout.Y_AXIS));

		
		JButton button3 = new JButton("Panel 3 Button");
		panel3.add(BorderLayout.CENTER,button3);
		
		JLabel lable1 = new JLabel("1. Enter UserName: ");
		JTextField field1 = new JTextField(20);
		field1.setText("John Cena");
		
		JLabel lable2 = new JLabel("2. Enter Password: ");
		JTextField field2 = new JTextField(20);
		field2.setText("******");
		
		panel3.add(lable1);
		panel3.add(field1);
		panel3.add(lable2);
		panel3.add(field2);
		
		JLabel lable3 = new JLabel("3. Description: ");
		JTextArea area1 = new JTextArea(10,20);
		JScrollPane scrollPane = new JScrollPane(area1);
		area1.setLineWrap(true);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		
		panel3.add(lable3);
		panel3.add(scrollPane);
		
		JLabel lable4 = new JLabel("4. Form Types: ");
		String[] forms = {"PCD","FCD","SOP","QP","WI","RD","DC","CR"};
		JList<String> list = new JList<String>(forms);
		
		JScrollPane scroller = new JScrollPane(list);
		scroller.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scroller.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

		panel3.add(lable4);
		panel3.add(scroller);

		list.setVisibleRowCount(4);

		panel3.add(BorderLayout.SOUTH,button3);



	}

}
