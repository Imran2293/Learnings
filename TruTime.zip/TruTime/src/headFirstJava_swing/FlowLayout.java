package headFirstJava_swing;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class FlowLayout {

	JFrame frame;
	
	public static void main(String[] args) {

		FlowLayout fl = new FlowLayout();
		fl.go();
		
	}

	
	void go(){
		
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.GRAY);
		panel.setLayout(new BoxLayout(panel,BoxLayout.Y_AXIS));

		JButton button1 = new JButton("Button in the West");
		
		JButton button2 = new JButton("Button in the Center");
		
		JButton button3 = new JButton("Button in the East");
		
		panel.add(button1);
		panel.add(button2);
		panel.add(button3);
		
		frame.getContentPane().add(BorderLayout.EAST,panel);
		
		frame.setSize(400, 400);
		frame.setVisible(true);
		
		
		
	}
}
