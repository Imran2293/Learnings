package headFirstJava_swing;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class LayoutManager {

	public static void main(String[] args) {

		LayoutManager lm = new LayoutManager();
		lm.go();
		
	}
	
	void go(){
		
		JFrame frame = new JFrame();
		JPanel jp1 = new JPanel();
		jp1.setBackground(Color.BLACK);
		JPanel jp2 = new JPanel();
		jp2.setBackground(Color.ORANGE);
		
		frame.getContentPane().add(jp1);
		frame.getContentPane().add(jp2);

		frame.setSize(200, 200);
		frame.setVisible(true);
		
		Component add1 = jp1.add(BorderLayout.WEST,new JButton("Button 1"));
		/*add1.setSize(300, 300);
		add1.setVisible(true);*/
		Component add2 = jp1.add(BorderLayout.CENTER,new JButton("Button 2"));
		/*add2.setSize(300, 300);
		add2.setVisible(true);*/

		Component add3 = jp1.add(BorderLayout.EAST,new JButton("Button 3"));
		/*add3.setSize(300, 300);
		add3.setVisible(true);*/

		
		jp2.add(jp1);
		
		
	}

}
