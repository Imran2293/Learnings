package headFirstJava_swing;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class SimpleAnimation {
	
	int x=200;
	int y=200;

	public static void main(String[] args) {
		
		SimpleAnimation sa = new SimpleAnimation();
		sa.go();
	}
	
	public void go(){
		
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		DrawPanel dp = new DrawPanel();
		
		frame.getContentPane().add(dp);
		
		frame.setSize(300,300);
		frame.setVisible(true);
		
		for(int i= 0 ; i<200; i++){
			
			x++;
			y++;
			
			dp.repaint();
			
			try{
				Thread.sleep(50);
				
			}catch(Exception e){
				
			}
			
		}
		
		
	}
	
	class DrawPanel extends JPanel {
		
		public void paintComponent(Graphics g){
			
			g.setColor(Color.WHITE);
			g.fillRect(0, 0, getWidth(), getHeight());
			
			g.setColor(Color.ORANGE);
			g.fillOval(x, y, 55,55);
		}
		
		
	}

}
