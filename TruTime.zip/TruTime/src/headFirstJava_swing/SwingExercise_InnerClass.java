package headFirstJava_swing;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class SwingExercise_InnerClass  {

	JFrame frame;
	JButton jb;

	public static void main(String[] args) {

		SwingExercise_InnerClass se = new SwingExercise_InnerClass();
		se.go();
		
//		Inner in = se.new Inner();

	}

	public void go() {

		frame = new JFrame();

		jb = new JButton("B");

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		jb.addActionListener(new Inner());

		frame.getContentPane().add(BorderLayout.SOUTH, jb);
		frame.setSize(300, 300);
		frame.setVisible(true);

	}

	class Inner implements ActionListener {
		
		@Override
		public void actionPerformed(ActionEvent e) {

			if (jb.getText().equals("A")) {
				jb.setText("B");
			}

			else {
				jb.setText("A");
			}
		}
	}

}
