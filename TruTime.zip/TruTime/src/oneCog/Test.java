package oneCog;

public class Test {
	
	public static void main(String args[][]){
		int[][] intArray = {{1,2,3},{4,5},{6,7,8}};
		System.out.println(intArray[1][1]);
	}

}
