package oneCog;

public class ReverseString {

	public static void main(String[] args) {
		String text = "I am a Software Tester";
//		char[] cs = text.toCharArray();
//		for(int i=cs.length-1; i >=0 ; i--){
//			System.out.print(cs[i]);
//		}
//		
//		StringBuilder build = new StringBuilder();
//		build.append(text);
//		build = build.reverse();
//		System.out.println(build);
		String[] arr = text.split(" ");
		StringBuilder buil = new StringBuilder();
		
		
	}

}
