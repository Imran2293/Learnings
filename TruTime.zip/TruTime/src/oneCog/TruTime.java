package oneCog;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TruTime {

	public static void main(String[] args) throws AWTException {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\rj815\\Selenium\\Driver\\chromedriver.exe");
		
		ChromeOptions options = new ChromeOptions();
		options.addArguments("disable-infobars");
		WebDriver driver = new ChromeDriver(options);
		
		Runtime.getRuntime();
		
		Robot rb = new Robot();
		rb.mouseMove(10, 20);
		rb.mousePress(InputEvent.BUTTON1_DOWN_MASK);
		
		rb.mousePress(InputEvent.BUTTON3_DOWN_MASK);
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("el=document.elementFromPoint(25,100)");
		
		WebElement element = driver.findElement(By.xpath("//*[@id='content']/div[1]/div/div/div/input"));
		js.executeScript("arguments[0].click();",element);
		
		driver.get("https://cummins365.sharepoint.com/sites/GRP_QSIDev1/SitePages/DocumentControl.aspx?DocType=PP&FormType=Customized");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		
		// Document Title
		driver.findElement(By.xpath("//*[@id='content']/div[1]/div/div/div/input")).sendKeys("Document No 1"); 
				
		 //Select Document Number Drop down_1 & Document Number_2 
		driver.findElement(By.xpath("//*[contains(text(),'Document Number')]//following::span[1]")).click();
		driver.findElement(By.xpath("//*[contains(@class,'dropdownItemsWrapper')]//following::button[4]")).click();
		driver.findElement(By.xpath("//*[@id='content']/div[3]/div/div/div/input")).sendKeys("001");
		
		try {
	        WebDriverWait wait = new WebDriverWait(driver, 2);
	        wait.until(ExpectedConditions.alertIsPresent());
	        Alert alert = driver.switchTo().alert();
	        alert.accept();
	    } catch (Exception e) {
	        //exception handling
		} 
		
		//Select Standard Option 
        WebElement SelectStand = driver.findElement(By.xpath("//*[contains(text(),'Document Number')]//following::span[4]"));
        SelectStand.click();
        List<WebElement> StandOptions=driver.findElements(By.xpath("//*[contains(@class,'dropdownItemsWrapper')]//following::button[1]"));
        for(int i=0;i<StandOptions.size();i++)
        {
              WebElement StandardSelect= driver.findElement(By.xpath("//*[contains(@class,'dropdownItemsWrapper')]//following::button["+(i+1)+"]"));
              String PrintStand= driver.findElement(By.xpath("//*[contains(@class,'dropdownItemsWrapper')]//following::button["+(i+1)+"]")).getText();
              if (PrintStand.contains("IATF"))
              {
                    StandardSelect.click();
                    break;
              }
        }

        // Click on Add Department
        WebElement Depart = driver.findElement(By.xpath("//*[contains(text(),'Department')]//following::i[1]"));
        Depart.click();
        
        // Select Department
        Select Department = new Select(driver.findElement(By.id("MultiSelectdeptDlgId")));
        Department.selectByIndex(2);
        
        // Save Department
        driver.findElement(By.xpath("//*[contains(text(),'Select Department')]//following::button[2]")).click();
        
        //Click on Add Area
        WebElement Area = driver.findElement(By.xpath(("//*[contains(text(),'Department')]//following::i[2]")));
        Area.click();
        
        //Select Area
        Select SelArea = new Select(driver.findElement(By.id("MultiSelectareaDlgId")));
        SelArea.selectByIndex(2);

        //Save Area
        driver.findElement(By.xpath("//*[contains(text(),'Select Area')]//following::button[2]")).click();
        
        //Click on Add Type of Document
        WebElement type = driver.findElement(By.xpath("//*[contains(text(),'Department')]//following::i[3]"));
        type.click();
        
        //Select the document type
        Select DocType = new Select(driver.findElement(By.id("MultiSelecttypeofDocumentDlgId")));
        DocType.selectByIndex(2);
        
        //Save Type Of Document
        driver.findElement(By.xpath("//*[contains(text(),'Select Type of Document')]//following::button[2]")).click();

        
        //Release Schedule
        driver.findElement(By.xpath("//*[contains(text(),'When Approved')]")).click();
        //driver.findElement(By.xpath("//*[contains(text(),'Use Days Entered')]")).click();
        //driver.findElement(By.xpath("//*[contains(text(),'Use Date Entered')]")).click();
        
        
        
      
	}

}
