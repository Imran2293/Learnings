package oneCog;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class RemoveDupsString {

	public static void main(String[] args) {
		
//		String str = "ImranHussainMohammed";
//		char[] str1 = str.toCharArray();
//		for(int i=0; i<str1.length; i++){
//			for(int j=i+1; j<str1.length;j++){
//				if(str1[i]==str1[j]){
//					System.out.println(str1[i]);
//			}
//			
//			}
//		}
		
		String name = "ImranHussainMohammed";
		String lowerCase = name.toLowerCase();
		Set<Character> unique = new HashSet<Character>();
		Set<Character> duplicate = new HashSet<Character>();
		for(int i=0;i<lowerCase.length()-1;i++){
			if(!unique.add(lowerCase.charAt(i))){
				duplicate.add(lowerCase.charAt(i));
			}
		}
		
		System.out.println(duplicate);
		

	}

}
