package oneCog;

import java.util.LinkedHashSet;
import java.util.Set;

public class PrintUnique {

	public static void main(String[] args) {
		String str = "PayPal India";
		char[] toChar = str.toCharArray();
//		System.out.println(toChar);
		Set<Character> st = new LinkedHashSet<Character>();
		
		for (Character each : toChar) {
			st.add(each);
		
			if(st.contains(each)){
				System.out.println("");
			}else{
				System.out.println(st);
			}
			
		}			//System.out.println(st);
		
	}

}
