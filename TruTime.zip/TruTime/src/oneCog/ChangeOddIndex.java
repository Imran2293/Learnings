package oneCog;

public class ChangeOddIndex {

	public static void main(String[] args) {
		String text = "change";
		StringBuffer sb = new StringBuffer();
		char[] cs = text.toCharArray();

		for( int i=0; i<cs.length; i++){
			char c = cs[i];
			
			if( i%2 != 0){
				
			//	c = cs.toUpperCase(c);
				
			}
		}
	}

}
