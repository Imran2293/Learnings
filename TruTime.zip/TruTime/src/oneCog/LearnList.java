package oneCog;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LearnList {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\rj815\\Selenium\\Driver\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.zoomcar.com/chennai/search/query?lat=12.9416037&lng=80.2362096&starts=2019-10-18%2011%3A00&ends=2019-10-18%2017%3A00&type=zoom_later&bracket=with_fuel");
		driver.manage().window().maximize();
		List<WebElement> pricelist = driver.findElementsByXPath("//div[@class='price']");
		List<Integer> list = new ArrayList<Integer>();
		for (WebElement each1 : pricelist) {
			String cost = each1.getText();
			String PriceAlone = cost.replaceAll("[^0-9]", "");
			int IntPrice = Integer.parseInt(PriceAlone);
			list.add(IntPrice);
			Collections.sort(list);
			Collections.reverse(list);
			
			}
		System.out.println(list.get(0));
		Integer maxprice = list.get(0);
		
		

		
	}

}
