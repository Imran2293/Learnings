package oneCog;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ReverseSort {

	public static void main(String[] args) {
		List<String> cmp = new ArrayList<String>();
		cmp.add("CTS");
		cmp.add("HCL");
		cmp.add("Aspire");
		cmp.add("Infosys");
//		Collections.sort(cmp);
		Arrays.sort(cmp.toArray(),Collections.reverseOrder());
//		Collections.reverse(cmp);
		System.out.println(cmp);
	}

}
