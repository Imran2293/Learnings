package oneCog;

import java.util.Arrays;

public class DuplicateNumbers {

	public static void main(String[] args) {
		int[] num = {1,2,1,22,23,34,44,33,34,22,1,34};
		Arrays.sort(num);
		for(int i=0; i<num.length-1; i++){
			
			if(num[i] == num[i+1]){
				System.out.print(num[i+1]);
			}
		}
	}

}
