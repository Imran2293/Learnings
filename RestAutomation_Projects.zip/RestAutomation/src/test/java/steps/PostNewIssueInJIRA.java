package steps;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;


public class PostNewIssueInJIRA {
	
	public static RequestSpecification request;
	public static Response response;
	
	@Given("Request URL is inititated")
	public void initiateRequestEndPoint() {
		
		RestAssured.baseURI = "https://api-mar2020.atlassian.net/rest/api/2/search";
	}

	@And("Authorization is performed in JIRA")
	public void authorize() {
		RestAssured.authentication = RestAssured.preemptive().basic("rajalakshmi.govindarajan@testleaf.com", "kEJxzmhkQzvdeP8iysWN2D1B");

	}
	
	@When("Post Request is with body")
	public void postRequestWithBody() {
		
		response = RestAssured.given().log().all().param("project","MAR").contentType(ContentType.JSON)
				.body("{\\r\\n\" + \r\n" + 
				"						\"    \\\"fields\\\": {\\r\\n\" + \r\n" + 
				"						\"       \\\"project\\\":\\r\\n\" + \r\n" + 
				"						\"       {\\r\\n\" + \r\n" + 
				"						\"          \\\"key\\\": \\\"MAR\\\"\\r\\n\" + \r\n" + 
				"						\"       },\\r\\n\" + \r\n" + 
				"						\"       \\\"summary\\\": \\\"New Defect\\\",\\r\\n\" + \r\n" + 
				"						\"       \\\"description\\\": \\\"Creating of an issue using project keys and issue type names using the REST API by Imran\\\",\\r\\n\" + \r\n" + 
				"						\"       \\\"issuetype\\\": {\\r\\n\" + \r\n" + 
				"						\"          \\\"name\\\": \\\"Bug\\\"\\r\\n\" + \r\n" + 
				"						\"       }\\r\\n\" + \r\n" + 
				"						\"   }\\r\\n\" + \r\n" + 
				"						\"}").post();
		
		JsonPath jsonResponse = response.jsonPath();
		String LatestIssue = jsonResponse.get("issues[0].id");
		
		System.out.println("Last Created Issue Id is: "+ LatestIssue );

	}
	
	@Then("Verify that the Response code is (.*)$")
	public void verifyStatusCode(int code) {
		
		int statusCode = response.getStatusCode();
		System.out.println(statusCode);
		
		if(statusCode == code) {
			System.out.println("Response code matches");
		}else {
			System.out.println("Response doesn't match");
		}

	}
	
	@And("Response time is within 5 seconds")
	public void verifyResponseTime() {
		long responseTime = response.getTime();
		
		if(responseTime < 5000) {
			System.out.println("Response Time is within 5s");
		}
		else {
			System.out.println("Response Time greater than 5s");
		}
	}
	

}
