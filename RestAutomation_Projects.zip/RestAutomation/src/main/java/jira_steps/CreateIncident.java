package jira_steps;

import java.io.File;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncident {

	public static String sys_id;
	public static RequestSpecification request;
	public static Response response;
	
	File fileName = new File("./data1.json");
	
	@Given("Request URL is Initiated")
	public void initiateRequestEndPoint() {
		
		RestAssured.baseURI = "https://dev76145.service-now.com/api/now/table/change_request";
	}

	@And("Authorization is performed")
	public void authorize() {
		RestAssured.authentication = RestAssured.basic("admin", "Snow@123");

	}
	
	@When("Body is posted with Json file (.*)$")
	public void postRequest(String fileName) {
		
		response = RestAssured.given().log().all().contentType(ContentType.JSON).body(fileName).post();

	}
	
	@Then("Status code should be (.*)$")
	public void verifyStatusCode(int code) {
		
		int statusCode = response.getStatusCode();
		System.out.println(statusCode);
		
		if(statusCode == code) {
			System.out.println("Response code matches");
		}else {
			System.out.println("Response doesn't match");
		}

	}
	
	@And("Response time within 5 seconds")
	public void verifyResponseTime() {
		long responseTime = response.getTime();
		
		if(responseTime < 5000) {
			System.out.println("Response Time is within 5s");
		}
		else {
			System.out.println("Response Time greater than 5s");
		}
	}
	
	
}
