package learnChaining;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class CreateCR extends BaseRequest{

	@Test
	void PostCRs() {
									
				Response postResponse = request.body("{\r\n" + 
						"	\r\n" + 
						"	\"short_description\"	:	\"This is created by Imran Hussain\",\r\n" + 
						"	\"description\"		:	\"Sample CR Document\",\r\n" + 
						"	\"type\"				:	\"Normal\"\r\n" + 
						"	\r\n" + 
						"}").post();
				
				JsonPath jsonResponse = postResponse.jsonPath();
				
				sys_id = jsonResponse.get("result.sys_id");
				
				System.out.println(jsonResponse.get("result.sys_id"));
				
				System.out.println("POST Response Status is: "+ postResponse.getStatusCode());
				
	}
}
