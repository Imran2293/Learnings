package learnChaining;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class DeleteCR extends BaseRequest {

	@Test(dependsOnMethods = "learnChaining.CreateCR.PostCRs")
	void DeleteCRs() {
		
				Response deleteResponse = request.delete(sys_id);
				
				System.out.println("Response Status is: "+deleteResponse.getStatusCode());
				
				
	}
}
