package exercise_1;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class Exercise_No_1 {

	@Test
	void getWeather() {
		
		RestAssured.baseURI = "http://restapi.demoqa.com/utilities/weather/city/Chennai";
		
		Response response = RestAssured.get();
		
		int statusCode = response.getStatusCode();
		
		System.out.println(statusCode);
		
		String Body = response.getBody().asString();
		
		System.out.println(Body);
	}
	
}
