package basics;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class DelCR {

	@Test
	void DeleteCRs() {
		
				// Step 1: Get the URL / Endpoint for the services		
				RestAssured.baseURI = "https://dev76145.service-now.com/api/now/table/change_request";
				
		        // Step 2: Authentication (basic)
				RestAssured.authentication = RestAssured.basic("admin", "Snow@123");
				
				Response response = RestAssured
						.given()
						.log()
						.all()
						.contentType(ContentType.JSON)
						.delete("51265a85db145010bc6253184b961937");
				
				System.out.println("Response Status is: "+response.getStatusCode());
				
				response.prettyPrint();
				
	}
}
