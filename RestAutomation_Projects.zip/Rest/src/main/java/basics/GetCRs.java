package basics;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;

public class GetCRs {
	
	@Test
	void getSelectiveCRs() {
		
		// Step 1: Get the URL / Endpoint for the services		
		RestAssured.baseURI = "https://dev76145.service-now.com/api/now/table/change_request";
		
        // Step 2: Authentication (basic)
		RestAssured.authentication = RestAssured.basic("admin", "Snow@123");
		
		// Step 3: Add Query Parameters
		Map<String,String> parametersMap = new HashMap<String,String>();
		parametersMap.put("state", "-5");
		parametersMap.put("type", "normal");
		parametersMap.put("sysparm_fields", "number,sys_id");
		
        // Step 4: Request type - Get -> Response --> To get Response in XML format
		Response response = RestAssured
				.given()
				.accept(ContentType.XML)
				.params(parametersMap)
				.get();
		
        // Step 4: Validate (Response -> Status Code : 200)
		System.out.println(response.getStatusCode());
		
		
		response.prettyPrint();

		XmlPath xmlResponse = response.xmlPath();
		
		List<String> listofNumbers = xmlResponse.getList("response.result.number");
		System.out.println(listofNumbers.size());
		
		

	}

}
