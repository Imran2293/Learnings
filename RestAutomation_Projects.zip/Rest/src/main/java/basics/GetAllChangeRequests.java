package basics;

import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class GetAllChangeRequests {

	@Test
	void getAllChangeRequest() {
		
		RestAssured.baseURI = "https://dev76145.service-now.com/api/now/table/change_request";
		
		RestAssured.authentication = RestAssured.basic("admin", "Snow@123");
		
		Response response = RestAssured.get();
		
		System.out.println(response.getStatusCode());
		
		System.out.println(response.getContentType());
		
		System.out.println(response.getTimeIn(TimeUnit.MILLISECONDS));
		
//		System.out.println(response.prettyPrint());

	} 
	
}
