package basics;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class PostCRNoBody {

	@Test
	void PostCRs() {
		
				// Step 1: Get the URL / Endpoint for the services		
				RestAssured.baseURI = "https://dev76145.service-now.com/api/now/table/change_request";
				
		        // Step 2: Authentication (basic)
				RestAssured.authentication = RestAssured.basic("admin", "Snow@123");
				
				Response response = RestAssured
						.given()
						.contentType(ContentType.JSON)
						.post();
				
				JsonPath jsonResponse = response.jsonPath();
				System.out.println(jsonResponse.get("result.sys_id"));
				
	}
}
