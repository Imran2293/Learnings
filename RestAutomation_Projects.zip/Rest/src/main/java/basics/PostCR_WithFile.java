package basics;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class PostCR_WithFile {

	@Test
	void PostCRs() {
		
				// Step 1: Get the URL / Endpoint for the services		
				RestAssured.baseURI = "https://dev76145.service-now.com/api/now/table/change_request";
				
		        // Step 2: Authentication (basic)
				RestAssured.authentication = RestAssured.basic("admin", "Snow@123");
				
				//Create File
				
				File fileSrc = new File("C:\\\\Users\\\\S.Y.AHAMED ASIK\\\\Desktop\\\\REST API\\\\Rest\\\\target\\\\data1.json");
				
				Response response = RestAssured
						.given()
						.contentType(ContentType.JSON)
						.body(fileSrc)
						.post();
				
				System.out.println("Response Status is: "+response.getStatusCode());
				
				JsonPath jsonResponse = response.jsonPath();
				System.out.println(jsonResponse.get("result.sys_id"));
				
				response.prettyPrint();
				
	}
}
