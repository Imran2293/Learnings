package jira;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class GetIssuesWithin24hrs {
	
	@Test
	void getIssues() throws ParseException {
		
		String myURL = "https://api-mar2020.atlassian.net/rest/api/2";
		
		RestAssured.baseURI = myURL;
		
		RestAssured.authentication = RestAssured.preemptive().basic("rajalakshmi.govindarajan@testleaf.com", "kEJxzmhkQzvdeP8iysWN2D1B");
		
	/*	Map<String,String> parameters = new HashMap<String,String>();
		parameters.put("project", "MAR");
		parameters.put("sysparm_fields", "created");*/
		
		Response response = RestAssured
				.given()
				.accept(ContentType.JSON)
				.log()
				.all()
//				.param("maxResults","1")
				.get("/search?jql=project='MAR'");
		
//		response.prettyPrint();
		
		System.out.println("Response Status code is: "+ response.statusCode());
		
		JsonPath jsonResponse = response.jsonPath();
		
		int totalissues = jsonResponse.get("total");
		System.out.println("Total Issues:"+ totalissues);
		
		List<String> getCreatedDate = jsonResponse.getList("issues.fields.created");
		
//		System.out.println(Arrays.toString(getCreatedDate.toArray()));
				
		Date crntDate = new Date();
		long currentTime = crntDate.getTime();
		System.out.println("Current Time in Milliseconds "+currentTime);
		
		long strt_time = 24*60*60*1000;
		System.out.println("Start Time in Milliseconds "+ strt_time);
		
		long diff_time = currentTime-strt_time;
		System.out.println("Diff Time in Milliseconds "+ diff_time);
		
		for (int i = 0; i < getCreatedDate.size(); i++) {
			
			DateFormat sdf = new SimpleDateFormat("YYYY-MM-DD'T'HH:MM:SS.SSS Z");
			Date date = sdf.parse(getCreatedDate.get(i).replace("+0530", " +0530"));
			
			long createdTime = date.getTime();
			
			if(createdTime  <= diff_time) {
				System.out.println(jsonResponse.get("issues[i].id"));
			}
				
		}

		}
	}


