package jira;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class CreateIssueWithAttachment {
	
	@Test
	void CreateIssue () {
		
		// Step 1: Get the URL / Endpoint for the services
		
		RestAssured.baseURI = "https://api-mar2020.atlassian.net/rest/api/2/issue";
		
		 // Step 2: Authentication (basic)
		
		RestAssured.authentication = RestAssured.preemptive().basic("rajalakshmi.govindarajan@testleaf.com", "kEJxzmhkQzvdeP8iysWN2D1B");
		
		// Step 3: Get Response of POST request
		
		Response response = RestAssured
				.given()
				.contentType(ContentType.JSON)
				.body("{\r\n" + 
						"    \"fields\": {\r\n" + 
						"       \"project\":\r\n" + 
						"       {\r\n" + 
						"          \"key\": \"MAR\"\r\n" + 
						"       },\r\n" + 
						"       \"summary\": \"New Defect\",\r\n" + 
						"       \"description\": \"Creating of an issue using project keys and issue type names using the REST API by Imran\",\r\n" + 
						"       \"issuetype\": {\r\n" + 
						"          \"name\": \"Bug\"\r\n" + 
						"       }\r\n" + 
						"   }\r\n" + 
						"}")
				.post();
		
		// Step 4: Print the Status code of Response
		
		System.out.println("Response Status code is: "+ response.statusCode());
		
		// Step 5: Parse the Response into JSON format
		
		JsonPath jsonPath = response.jsonPath();
		
		// Get the issue ID & Print it
		
		String id = jsonPath.get("id");
	
		System.out.println("Issue ID is: " + id);
		
		response.prettyPrint();
		
		//Add attachment to the created issue
		
		// Step 6: Pass the Issue ID in the URI and get the Response of POST request
		
		Response response1 = RestAssured
		.given()
		.header("X-Atlassian-Token", "nocheck")
		.multiPart(new File("C:\\Users\\S.Y.AHAMED ASIK\\Desktop\\Sample.txt"))
		.when().post("https://api-mar2020.atlassian.net/rest/api/2/issue/"+id+"/attachments");

		// Step 7: Print the Status code of Response

		System.out.println("Response Status code of Add Attachment is: "+ response1.statusCode());

	}

}
