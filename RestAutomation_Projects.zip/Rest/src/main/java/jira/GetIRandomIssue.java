package jira;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class GetIRandomIssue {
	
	@Test
	void getIssues() {
		
		RestAssured.baseURI = "https://api-mar2020.atlassian.net/rest/api/2/search";
		
		RestAssured.authentication = RestAssured.preemptive().basic("rajalakshmi.govindarajan@testleaf.com", "kEJxzmhkQzvdeP8iysWN2D1B");
		
		Map<String,String> parameters = new HashMap<String,String>();
		parameters.put("project", "MAR");
//		parameters.put("id", "10005");
		
		Response response = RestAssured
				.given()
				.accept(ContentType.JSON)
				.params(parameters)
				.get();
		
//		response.prettyPrint();
		
		System.out.println("Response Status code of GET is: "+ response.statusCode());
		
		JsonPath jsonResponse = response.jsonPath();
		
		int totalissues = jsonResponse.get("total");
		System.out.println("Total Issues:"+ totalissues);
		
		String id = (String) jsonResponse.getList("issues.id").get(0);
		
		System.out.println("ID of First Issue is :"+ id);
		
//		int random_id = response.issues[(int) Math.floor(Math.random()* totalissues)+1)].id;
		
		// Delete the Issue
		
		Response response1 = RestAssured.given()
		.contentType(ContentType.JSON)
		.delete("https://api-mar2020.atlassian.net/rest/api/2/issue/"+id);
		
		System.out.println("Response Status code of DELETE is: "+ response1.statusCode());


	}

}
