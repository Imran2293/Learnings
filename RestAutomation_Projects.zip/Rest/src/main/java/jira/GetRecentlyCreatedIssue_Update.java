	package jira;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class GetRecentlyCreatedIssue_Update {
	
	@Test
	void CreateIssue () {
		
		// Step 1: Get the URL / Endpoint for the services
		
		RestAssured.baseURI = "https://api-mar2020.atlassian.net/rest/api/2/search";
		
		 // Step 2: Authentication (basic)
		
		RestAssured.authentication = RestAssured.preemptive().basic("rajalakshmi.govindarajan@testleaf.com", "kEJxzmhkQzvdeP8iysWN2D1B");
		
		// Step 3: Get Response of POST request
		
		Map<String,String> parameters = new HashMap<String,String>();
		parameters.put("project", "MAR");
		
		Response response = RestAssured
				.given()
				.accept(ContentType.JSON)
				.params(parameters)
				.get();
		
		// Step 4: Print the Status code of Response
		
		System.out.println("Response Status code is: "+ response.statusCode());
		
		// Step 5: Parse the Response into JSON format
		
		JsonPath jsonPath = response.jsonPath();
		
		// Get the issue ID & Print it
		
		int total = jsonPath.get("total");
		
		System.out.println("Total No. of Issues:"+ total);
		
		List<Integer> list = jsonPath.getList("issues.id");
		
		for (int i = 0; i < list.size()-1; i++) 
			   for (int k = i+1; k < list.size(); k++) 
			      if(list.get(i) > list.get(k))
			         System.out.println("Recent Issue is :"+ list.get(i));
	
	}

}
