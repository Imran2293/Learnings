package requestChaining;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class DelCR extends BaseRequest {

	@Test(dependsOnMethods = "requestChaining.PostCRNoBody")
	void DeleteCRs() {
		
				Response deleteResponse = request.delete(sys_id);
				
				System.out.println("Response Status is: "+deleteResponse.getStatusCode());
				
				
	}
}
