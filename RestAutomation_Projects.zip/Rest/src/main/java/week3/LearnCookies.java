	package week3;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import static org.hamcrest.Matchers.equalTo;

public class LearnCookies {
	
	@Test
	void CreateIssue () {
		
		// Step 1: Get the URL / Endpoint for the services
		
		RestAssured.baseURI = "https://api-mar2020.atlassian.net/rest/api/2/search";
		
		 // Step 2: Authentication (basic)
		
		RestAssured.authentication = RestAssured.preemptive().basic("rajalakshmi.govindarajan@testleaf.com", "kEJxzmhkQzvdeP8iysWN2D1B");
		
		List<Header> headerList = new ArrayList<Header>();
		headerList.add(new Header("content-type","application/json"));
		headerList.add(new Header("accept","*/*"));
		
		Headers headerMap = new Headers(headerList);
		
		// Step 3: Get Response of POST request
		
		Map<String,String> parameters = new HashMap<String,String>();
		parameters.put("project", "MAR");
		
		Response response = (Response) RestAssured
				.given()
				.headers(headerMap)
				.params(parameters)
				.get();
		
		Map<String, String> cookiesMap = response.getCookies();
		for (Entry<String,String> eachCookie : cookiesMap.entrySet()) {
			System.out.println(eachCookie.getKey());
			System.out.println(eachCookie.getValue());
			
		}
		
		// Step 4: Print the Status code of Response
		
		System.out.println("Response Status code is: "+ response.statusCode());
		
		// Step 5: Parse the Response into JSON format
		
		JsonPath jsonPath = response.jsonPath();
		
		// Get the issue ID & Print it
		
		int total = jsonPath.get("total");
		
		System.out.println("Total No. of Issues:"+ total);
		
		
	
	}

}
