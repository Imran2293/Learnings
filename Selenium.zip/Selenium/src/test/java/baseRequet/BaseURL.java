package baseRequet;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeSuite;

public class BaseURL {
	
	public ChromeDriver driver;
	
	@BeforeSuite
	public void intializeSetUp() {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\S.Y.AHAMED ASIK\\Desktop\\chromedriver_win32\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://leafground.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
	}

}
