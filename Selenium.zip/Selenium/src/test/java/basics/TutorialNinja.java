package basics;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class TutorialNinja {
	
@Test

public void intializeSetUp() {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\S.Y.AHAMED ASIK\\Desktop\\chromedriver_win32\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("http://tutorialsninja.com/demo");
		driver.manage().window().maximize();
		
		WebElement MyAccount = driver.findElementByXPath("//a[@title='My Account']");
		MyAccount.click();
		
		WebElement Register = driver.findElementByXPath("//a[text()='Register']");
		Register.click();
		
	}
}
