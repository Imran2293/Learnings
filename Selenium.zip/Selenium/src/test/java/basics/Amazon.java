package basics;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class Amazon {
	
@Test	
public void LaunchAmazon() {
	
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\S.Y.AHAMED ASIK\\Desktop\\chromedriver_win32\\chromedriver.exe");
	ChromeDriver driver = new ChromeDriver();
	driver.get("https://www.amazon.in/");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	
	/*WebElement Accounts = driver.findElementByXPath("(//span[text()='Account & Lists'])[1]");
	
	Actions build = new Actions(driver);
	build.moveToElement(Accounts);*/
	
	WebElement SignIn = driver.findElementByXPath("(//span[text()='Sign in'])[1]");
	SignIn.click();
}

}
