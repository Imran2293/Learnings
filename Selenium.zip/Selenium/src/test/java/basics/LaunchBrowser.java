package basics;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class LaunchBrowser {
	
	@Test
	public void Launch() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\S.Y.AHAMED ASIK\\Desktop\\chromedriver_win32\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.naukri.com");
		driver.manage().window().maximize();
		
		/*Close all other windows except parent*/
		
		Set<String> windowHandles = driver.getWindowHandles();
		String ParentWindow = driver.getWindowHandle();
		
		for (String eachWindow : windowHandles) {
			if(!ParentWindow.equals(eachWindow)) {
				driver.switchTo().window(eachWindow);
				driver.close();
			}
		}
				driver.switchTo().window(ParentWindow);
		
		/*
		 * Explicit wait to check if popup is visible or not
		*/		
	
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Sure']")));
		driver.findElementByXPath("//span[text()='Sure']").click();
		
	
/*		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("allow")));	
		driver.findElementById("allow").click();
*/
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		driver.findElementByXPath("//div[text()='Login']").click();
		
		WebElement EmailID = driver.findElementByXPath("//input[@placeholder=\"Enter your active Email ID / Username\"]");
		EmailID.sendKeys("imranhussain2209@gmail.com");
		
		
		WebElement Password = driver.findElementByXPath("//input[@type=\"password\"]");
		Password.sendKeys("Livelong@01");
		
		WebElement Submit = driver.findElementByXPath("//button[@type='submit']");
		Submit.click();
		
		
		}
	
		
	}


