package testcases;

import org.testng.annotations.Test;

import baseRequet.BaseURL;
import pages.HomePage;

public class TC001 extends BaseURL {

	@Test
	public void testCase01() {

		new HomePage()
		.clickMyAccount()
		.clickRegister()
		.enterFirstName();
	}
	
}
