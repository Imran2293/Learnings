package leafGround_Init;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeSuite;

public class LGBaseRequest {
	
	public ChromeDriver driver;
	
	@BeforeSuite
	public void initialSetUp()  {
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\S.Y.AHAMED ASIK\\Desktop\\chromedriver_win32\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.navigate().to("http://leafground.com/");
		driver.manage().window().maximize();
		
		
		/*// Edit Field 1
		
		WebElement EmailInput = driver.findElementById("email");
		EmailInput.sendKeys("abc@xyz.com");
		
		// Edit Field 2
		
		WebElement AppendField = driver.findElementByXPath("//input[@value='Append ']");
		AppendField.sendKeys("New values in to the field");
		String UpdatedAppendFieldValue = AppendField.getAttribute("value");
		System.out.println("Updated Append Field Value is "+ UpdatedAppendFieldValue);
		
		// Edit Field 3
		
		AppendField.sendKeys(Keys.TAB);
		
		WebElement UserName= driver.findElementByXPath("(//input[@name='username'])[1]");
		String DefaultValue = UserName.getAttribute("value");
		System.out.println("Default Value of UserName is"+ DefaultValue);
		
		//Edit Field 4
		
		WebElement ClearField= driver.findElementByXPath("(//input[@name='username'])[2]");
		ClearField.clear();
		String ClearFieldValue = ClearField.getAttribute("value");
		System.out.println("ClearFieldValue "+ ClearFieldValue);
		
		//Edit Field 5
		
		WebElement DisabledField = driver.findElement(By.xpath("//input[@disabled='true']"));
		boolean result = DisabledField.isEnabled();
		System.out.println("Field is enabled or not ? true/false "+ result);
		
		driver.navigate().back();*/

		
	}
	
	
	
}
