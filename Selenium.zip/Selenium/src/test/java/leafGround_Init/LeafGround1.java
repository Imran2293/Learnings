package leafGround_Init;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.hc.client5.http.classic.HttpClient;
import org.apache.hc.client5.http.classic.methods.HttpGet;
import org.apache.hc.client5.http.impl.classic.HttpClientBuilder;
import org.apache.hc.core5.http.HttpResponse;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeSuite;


public class LeafGround1 {
	
	public ChromeDriver driver;
	
	public static void main(String args[]) throws MalformedURLException, IOException {
		
		LeafGround1 lg = new LeafGround1();
		lg.initialSetUp();
				
		
	}
	public void initialSetUp() throws MalformedURLException, IOException {
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\S.Y.AHAMED ASIK\\Desktop\\chromedriver_win32\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.navigate().to("http://leafground.com/");
		driver.manage().window().maximize();
		
		driver.findElementByXPath("//a[@href='pages/Edit.html']").click();
		
		// Edit Field 1
		
		WebElement EmailInput = driver.findElementById("email");
		EmailInput.sendKeys("abc@xyz.com");
		
		// Edit Field 2
		
		WebElement AppendField = driver.findElementByXPath("//input[@value='Append ']");
		AppendField.sendKeys("New values in to the field");
		String UpdatedAppendFieldValue = AppendField.getAttribute("value");
		System.out.println("Updated Append Field Value is "+ UpdatedAppendFieldValue);
		
		// Edit Field 3
		
		AppendField.sendKeys(Keys.TAB);
		
		WebElement UserName= driver.findElementByXPath("(//input[@name='username'])[1]");
		String DefaultValue = UserName.getAttribute("value");
		System.out.println("Default Value of UserName is"+ DefaultValue);
		
		//Edit Field 4
		
		WebElement ClearField= driver.findElementByXPath("(//input[@name='username'])[2]");
		ClearField.clear();
		String ClearFieldValue = ClearField.getAttribute("value");
		System.out.println("ClearFieldValue "+ ClearFieldValue);
		
		//Edit Field 5
		
		WebElement DisabledField = driver.findElement(By.xpath("//input[@disabled='true']"));
		boolean result = DisabledField.isEnabled();
		System.out.println("Field is enabled or not ? true/false "+ result);
		
		driver.navigate().back();

		//Bond With Buttons
		
		driver.findElementByXPath("//a[@href='pages/Button.html']").click();

		
		// Button 1
		
		WebElement homeButton = driver.findElement(By.id("home"));
		homeButton.click();
		
		driver.navigate().back();
		
		//Button 2
		
		WebElement positionButton = driver.findElement(By.id("position"));
		int x = positionButton.getLocation().getX();
		int y = positionButton.getLocation().getY();
		System.out.println("Location of the Element is "+ x + " "+ y);
		
		//Button 3
		
		WebElement colorButton = driver.findElement(By.id("color"));
		String BackGroundColor = colorButton.getCssValue("background-color").toString();
		System.out.println("BackGround Color of the Element is "+ BackGroundColor);
		
		
		//Button 4
		
		WebElement SizeButton = driver.findElement(By.id("size"));
		int height = SizeButton.getSize().getHeight();
		int width = SizeButton.getSize().getWidth();
		System.out.println("Size of the Button is "+"Height: "+ height +" "+"Width: "+width);
		
		driver.navigate().back();
		
		//Play With HyperLinks
		
		driver.findElementByXPath("//a[@href='pages/Link.html']").click(); 
		
		// Link 1
		
		WebElement Link1 = driver.findElement(By.xpath("(//a[@href='../home.html'])[2]"));
		Link1.click();
		
		driver.navigate().back();
		
		//Link 2
		
		WebElement BrokenLink = driver.findElementByLinkText("Verify am I broken?");
		
		HttpURLConnection huc ;
		String url = BrokenLink.getAttribute("href");
		
		try {
		huc = (HttpURLConnection) new URL(url).openConnection();
		
		huc.setRequestMethod("HEAD");
		
		huc.connect();
		
		int responseCode = huc.getResponseCode();
		
		if(responseCode >= 400) {
			
			System.out.println(url+"Response Code: "+responseCode+ " Link is Broken");
		}else {
			System.out.println(url+" Link is valid");
		}
		
		} catch(MalformedURLException e) {
			e.printStackTrace();
		} catch(IOException e) {
			e.printStackTrace();
		}
		
		// Link 3
		
		List<WebElement> alist = driver.findElements(By.tagName("a"));
		int noOfLinks = alist.size();
		
		System.out.println("Total No. of Links in the Page: "+ noOfLinks);
		
		driver.navigate().back();
		
		// Interact With Pages
		
		driver.findElement(By.xpath("//a[@href='pages/Image.html']")).click();
		
		// BrokenImage
		
		WebElement image = driver.findElement(By.xpath("//img[@src='../images/abcd.jpg']"));
		
		HttpClient client = HttpClientBuilder.create().build();
		
		HttpGet request = new HttpGet(image.getAttribute("src"));
		
		HttpResponse response = client.execute(request);
		
		/*if (response.getStatusLine().getStatusCode() != 200) {
			System.out.println("Image is Broken");
		*/}
	
	}
	
	
	

