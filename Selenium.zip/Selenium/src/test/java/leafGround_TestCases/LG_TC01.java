package leafGround_TestCases;

import org.testng.annotations.Test;

import leafGround_Init.LGBaseRequest;
import pages.LGHomePage;

public class LG_TC01 extends LGBaseRequest {

	@Test
	public void TC001() {
		
		new LGHomePage()
		.ClickEdit()
		.emailInput()
		.AppendField()
		.UserNameField()
		.ClearField()
		.DisabledField()
		.BackToHome();
		
		
		
	}
}
