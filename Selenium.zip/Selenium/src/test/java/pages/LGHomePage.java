package pages;

import org.openqa.selenium.WebElement;

import leafGround_Init.LGBaseRequest;

public class LGHomePage extends LGBaseRequest {

	public LGEditPage ClickEdit() {
		
		WebElement EditPage = driver.findElementByXPath("//a[@href='pages/Edit.html']");
		EditPage.click();

		return new LGEditPage();
	}
	
}
