package pages;

import org.openqa.selenium.WebElement;

import baseRequet.BaseURL;

public class RegisterPage extends BaseURL {

	public RegisterPage enterFirstName() {
		
		WebElement FirstName = driver.findElementById("input-firstname");
		FirstName.sendKeys("Captain Jack");
		return this;

	}
	

}
