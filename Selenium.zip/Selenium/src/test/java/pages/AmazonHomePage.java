package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import baseRequet.BaseURL;

public class AmazonHomePage extends BaseURL {
	
	
	public void mouseHover() {
		
		WebElement Accounts = driver.findElementByXPath("(//span[text()='Account & Lists'])[1]");
		
		Actions build = new Actions(driver);
		build.moveToElement(Accounts);
	
		}
	
	
	public AmazonHomePage clickSignIn() {

		WebElement SignIn = driver.findElementByXPath("(//span[text()='Sign in'])[1]");
		SignIn.click();
		return this;
		
	}

	public RegisterPage clickRegister() {

		WebElement Register = driver.findElementByXPath("//a[text()='Register']");
		Register.click();
		
		return new RegisterPage();
		
	}
	
	
}
