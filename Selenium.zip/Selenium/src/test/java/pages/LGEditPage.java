package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import leafGround_Init.LGBaseRequest;


public class LGEditPage  extends LGBaseRequest {
	
	public LGEditPage emailInput() {
		
		WebElement EmailInput = driver.findElementById("email");
		EmailInput.sendKeys("abc@xyz.com");
		
		return this;
	}
	
	public LGEditPage AppendField() {
		
		WebElement AppendField = driver.findElementByXPath("//input[@value='Append ']");
		AppendField.sendKeys("New values in to the field");
		String UpdatedAppendFieldValue = AppendField.getAttribute("value");
		System.out.println("Updated Append Field Value is "+ UpdatedAppendFieldValue);
		AppendField.sendKeys(Keys.TAB);

		return this;
	}
	
	public LGEditPage UserNameField() {
		
		WebElement UserName= driver.findElementByXPath("(//input[@name='username'])[1]");
		String DefaultValue = UserName.getAttribute("value");
		System.out.println("Default Value of UserName is"+ DefaultValue);
		return this;
	}

	public LGEditPage ClearField() {
		
		WebElement ClearField= driver.findElementByXPath("(//input[@name='username'])[2]");
		ClearField.clear();
		String ClearFieldValue = ClearField.getAttribute("value");
		System.out.println("ClearFieldValue "+ ClearFieldValue);
		
		return this;
	}
	
	public LGEditPage DisabledField() {
		
		WebElement DisabledField = driver.findElement(By.xpath("//input[@disabled='true']"));
		boolean result = DisabledField.isEnabled();
		System.out.println("Field is enabled or not ? true/false "+ result);

		return this;

	}
	
	public LGBaseRequest BackToHome() {
		
		driver.navigate().back();
		return new LGBaseRequest();

	}
}
