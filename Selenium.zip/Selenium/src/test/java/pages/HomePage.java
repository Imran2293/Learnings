package pages;

import org.openqa.selenium.WebElement;

import baseRequet.BaseURL;

public class HomePage extends BaseURL {
	
	
	public HomePage clickMyAccount() {

		WebElement MyAccount = driver.findElementByXPath("//li[@class='dropdown open']");
		MyAccount.click();
		return this;
		
	}

	public RegisterPage clickRegister() {

		WebElement Register = driver.findElementByXPath("//a[text()='Register']");
		Register.click();
		
		return new RegisterPage();
		
	}
	
	
}
